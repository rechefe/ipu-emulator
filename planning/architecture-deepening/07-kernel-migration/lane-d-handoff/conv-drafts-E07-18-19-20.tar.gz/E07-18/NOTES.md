# E07-18 prep: merge the pointwise and depthwise twins

Draft only; nothing in the repo is edited. **Rebased on bfc3b65f** plus the
in-progress E07-17 working tree (`kernels/convolutions/conv_universal_tpl/`,
the family `pack.py` (`chunked`, `chunked_guard`, `fpb28_filters`), `masks.py`
(`border_mask`), `gen.py`, `registry.toml`), whose conventions these drafts
follow. Old paths are under `src/tools/ipu-apps/src/ipu_apps/kernels/convolutions/`:
`PW` = `pointwise_conv_unified/app.py`, `BN` = `pointwise_conv_unified_bn_activation/app.py`,
`DW` = `depthwise_conv_universal/app.py`, `DB` = `depthwise_conv_universal_bn_activation/app.py`.

## What changed since the first draft (f0fc8e2c)

- **One parameter set**, as conv_universal_tpl: the programs read
  `has_bias`/`apply_relu`; `bias`/`activation` are gone. Every query parameter
  is `query_required`, without a default (a template default would stand
  against an entry's fixed value).
- Family transforms reused: `chunked` (pointwise x/y, depthwise y),
  `chunked_guard` (depthwise x), E07-16's `conv_weight_groups` (pointwise
  `w [out, in, 1, 1]`). Only `pass0_bias` and `depthwise_filters` are new.
- Masks: `bytes = "../masks.py:<fn>"`, no kernel-folder shims; `border_mask` is
  E07-17's, `keep_all_mask` new.
- Pointwise tensors are `x`, `w`, `b`, so its golden is `op = "conv2d"` (no
  `reference.py`).
- Depthwise `filters` is always `[C, 10]` (bias first: DB's order), as
  conv_universal's always carries its bias column; `slot` became `fpb`.
- **Poisoned registers** (df3e2059): pointwise reads LR0 and LR7 before it
  writes them. Both are now `[abi]` presets of 0 (P1).

## Result (`_check/`, a throwaway tree: the checkout's `kernels/convolutions` + these drafts)

| Check | Result | Evidence |
|---|---|---|
| Program = E02 asm digest, all 39 cases of the 4 entries | equal | `_check/run_check.out` |
| `compare_setup` (poisoned), every legacy case | depthwise 22/22 `IDENTICAL`; pointwise 17/17 identical but `LR0`, `LR7: old 42405, new 0` (the presets, P1) | `_check/run_check.out` |
| `compare_legacy` (poisoned), every legacy case | 39/39 `yes \| yes`, equal cycles | `_check/compare_legacy.md` |
| Routing, every `(has_bias, apply_relu)`, refusals, the C = 1 tie, with E07-17's entries in the tree | today's answers | `_check/run_routing.out` |

The goldens were not run, because the checking interpreter has no torch; the
tolerances are still to be measured. Re-run: `sh ../E07-19/_check/mktree.sh`
(it builds both issues' tree), `. ../env.sh`, then from the repo root
`$PY E07-18/_check/run_check.py`, `run_legacy.py`, `run_routing.py`.

## Files

| Draft | Becomes |
|---|---|
| `pointwise_conv_tpl/{kernel.toml, pointwise_conv_tpl.asm, BUILD.bazel}` | `kernels/convolutions/pointwise_conv_tpl/` |
| `depthwise_conv_tpl/{kernel.toml, depthwise_conv_tpl.asm, reference.py, BUILD.bazel}` | `kernels/convolutions/depthwise_conv_tpl/` |
| `convolutions/registry_additions.toml` | appended to `kernels/convolutions/registry.toml`; then `bazel run //kernels:update_registry_bzl` |
| `convolutions/{pack,masks,gen}_additions.py` | appended to the family's `pack.py`, `masks.py`, `gen.py` (`gen.py` is for the proof commit only; the next commit moves to the seeded generators, as E07-16/17) |
| `_check/build_asm.py`, `_check/gen_tomls.py` | wrote the two `.asm` files (by diff) and the two `kernel.toml` files |
| `kernels/families.bzl` | `"pointwise_conv_tpl", "depthwise_conv_tpl"` in `KERNELS["convolutions"]` |

## Differences in each pair (each one is a function of the seed or of `apply_relu`)

Each `.asm` opens with `{%- set seeded = ... -%}` and
`{%- set activation = "relu" if apply_relu else "identity" -%}`.
`seeded = apply_relu` (pointwise; see OQ1) and `has_bias or apply_relu`
(depthwise, as conv_universal_tpl).

- **Pointwise:** 9 `seeded` hunks and 2 activation sites.
  1. `ADD LR5 LR7 CR1` vs `ADD LR5 LR7 {{ cr.fixed_idx_step }}`.
  2. Half A's bias seed `LD.MULT R0 LR12 {{ cr.b }} ;; MULT.EE LR7 CR1 0 LR7 CR15 ; ACC.ADD.FIRST`.
  3. The two W1 paths: `ACC.ADD.FIRST` vs `ACC.ADD`.
  4. `ADD LR1 LR1 LR5` vs `... CR1`.
  5. The same four in Half B.
  6. Activation: `ACTIVATE.QUANTIZE {{ activation }}` (twice).

  App side: the bias region (BN app.py:168) and CR10 = the bias base instead of `tail_size` (BN app.py:265-268).
- **Depthwise:** 20 `seeded` hunks (the same 6-7 in each of g0, main and gN) and 3 activation sites.
  1. The bias-seed word.
  2. `ADD LR10` moves from tap 1 to tap 5.
  3. Tap 1: `ACC.ADD.FIRST` vs `ACC.ADD`.
  4. The `INC.MODP2 LR4` moves from tap 5 to tap 7.
  5. The kr = -1 prefetch moves from tap 9 and the pre-loop word into the seed word.

  It is one pipeline, shifted by the seed cycle (9 vs 10 cycles per channel). App side: FPB 28 vs 25 and the slot of 9 vs 10 elements.

The generated headers are the plain twin's `#` block. Merging both twins'
notes and the `app.py` docstrings into the header (Q79) is a hand edit.

## Parameters

Both templates take the 11 universal parameters, all `query_required`.
Pointwise: `in_channels` min 8, multiple of 8; `out_channels` min 4, multiple
of 4; `width` max 128; kernel_size 1, stride 1, padding 0, dilation 1,
groups 1. Depthwise: kernel_size 3, stride 1, padding 1, dilation 1, width max
128. **`fpb` (depthwise)** is the one program value that is not a query
parameter: CR7 is 28 unseeded and 25 seeded, and a bool cannot enter
`[derived]` (`params._derived` passes ints only). Each entry fixes it (no
default), and `depthwise_filters` refuses an `fpb` that disagrees with the
seed. The coordinator asked for `bias != has_bias` to be refused with a
`[derived]` check "if cheap": it is not possible, for the same reason; the
pack's check is the guard.

## CR / LR maps (every value from the old `setup()`)

Pointwise (PW app.py:218-261; BN :265-268):

| Reg | Name | Value | Old source |
|---|---|---|---|
| CR0 | `x` (`row = 0`) | 0, the input base | PW :218-220 |
| CR2 | `mask` | base | :224 |
| CR3 | `y` | base | :225 |
| CR4 | `num_passes` | `ceil(in / 128)`, never read | :119, :234 |
| CR5 | `row_groups` | `ceil(height * cols / 128)` | :134, :235 |
| CR6 | `pipeline_limit_full` | 123 | :140, :236 |
| CR7 | `out_channels` | param | :237 |
| CR8 | `in_channels` | param (the row-group stride) | :238 |
| CR9 | `pipeline_limit_tail` | `tail_size - 5` (two's complement) | :240 |
| CR10 | `b` (when `apply_relu`) / `tail_size` (when `not apply_relu`, never read) | base / `in - (P - 1) * 128` | BN :268 / PW :241 |
| CR11 | `last_pass` | `num_passes - 1` | :242 |
| CR12 | `fixed_idx_step` | 128 | :249 |
| CR13 | `pass_stride` | 128 | :250 |
| CR14 | `w` | base | :226 |
| CR15 | default | dstructure(128) | :261 |
| LR0 | `input_row_base` | 0 (new preset, P1) | today's reset value |
| LR7 | `cyclic_s0` | 0 (new preset, P1) | today's reset value |

`cols` = `pointwise_pad_shape`'s width, the next power of 2 (convolutions/app.py:466-484);
`rows = row_groups * 128 / cols` for `chunked`.

Depthwise (DW app.py:258-310): CR2 `y` `{ offset = -1 }` (:286); CR3 `border_mask` (:287);
CR4 `cols` (:293); CR5 `filters` (:282); CR6 `in_channels` (:296); CR7 `fpb` (:297, DB 25);
CR8 `kernel_rows` = `ceil(C / fpb) * 2`, never read (:298); CR9 384 (:290); CR10 `x` (:281);
CR11 `(num_chunks - 1) * C + C` (:301-304); CR12 128; CR13 256; CR14 `256 - 2 * cols - 2` (:310);
CR15 `dstructure(128, 128 // cols - cols // 128)` (:261-270). There are no LR presets:
the program passes from poisoned LRs.

## Regions

- **Pointwise:** `x` (pinned at row 0, `row_groups * C` rows), `w` (`O * P`), `mask` (`after = "w"`, 1 row), `b` (`O * P`, when `apply_relu`), `y` (`row_groups * O`). This is PW app.py:150-157 / BN :163-171.
- **Depthwise:** `x` (C headroom rows + chunks), `filters` (`ceil(C / fpb) * 2`), `border_mask` (`after = "filters"`), `y` (`num_chunks * C`). This is DW :207-215.

## Pack transforms

| Name | Origin | Layout | Replaces |
|---|---|---|---|
| `chunked`, `chunked_guard` | E07-17 | padded to `[derived] rows` x `cols`, chunk-interleaved (with C headroom rows) | PW :201-206, :263-269; DW :207-221, :241-246, :312-318 |
| `conv_weight_groups` | E07-16 | `(O, C, 1, 1)`: 128 input channels a row | PW `_pack_kernel` :164-194 |
| `pass0_bias` | new | `(O,)` to `O * num_passes` rows, the bias at lane 0 of row `oc * P` | BN `_pack_bias` :209-225 |
| `depthwise_filters` | new | `(C, 10)`: seeded, 10-element slots, 25 to a block; unseeded, the 9 taps, 28 to a block | DW :97-120, DB :103-131 |

## Registry entries (`registry_additions.toml`) and routing

| `(has_bias, apply_relu)` | pointwise | depthwise |
|---|---|---|
| (F, F) | `pointwise_conv_unified` (`has_bias = false, apply_relu = false`) | `depthwise_conv_universal` (`..., fpb = 28`) |
| (F, T) | `pointwise_conv_unified_bn_activation` (`apply_relu = true`; zero bias) | refused, as today (DB :310 requires bias) |
| (T, T) | `pointwise_conv_unified_bn_activation` | `depthwise_conv_universal_bn_activation` (`has_bias = true, apply_relu = true, fpb = 25`) |
| (T, F) | refused (E07-20) | refused (E07-20) |

`depthwise_conv_tpl` costs 1. At C = 1, `groups = 1`, the depthwise kernel
also accepts a plain 3x3 query. Today `resolve` answers `conv_universal`,
with depthwise as an alternative; an equal cost would be a tie, which is an
error. Verified with E07-17's entries: the same answers and alternatives.

## Cases

The legacy data (`../gen.py`, seed 0, cases.py:125-130, 170-176) is for the
proof commit only.

| Kernel | Cases | Legacy ids |
|---|---|---|
| pointwise | `default`, `negative_bias` (bn) | named the same |
| pointwise | `sweep_128` ... `sweep_layer` | one-value list axes, named `<case>[in_channels=..,..]` = the legacy id |
| depthwise | `default`, `negative_outputs` (plain), `negative_bias` (bn) | named the same |
| depthwise | `c28_16` ... `c4_6x65` | `channels=C,height=H,width=W` needs `--case-map` (the map is in `_check/run_legacy.py`) |

Each entry's `cases` lists today's set.

## Tolerance

`fp32`, element outputs. Today's checks were `< 1e-3` (1x1) and `< 1e-2` (3x3).
Proposed: pointwise `FP32_LONG` (K reaches 256), depthwise `FP32_ORDER`. TO
MEASURE (E07-17 measured 5.6e-6 at K = 504).

## Benchmarks

`[benchmark]`: the pointwise points (8, identical in both twins,
`max_cycles = 200M`) and the depthwise union (13 points, `per = "in_channels"`,
50M).

## Tests from the old test files (for DELETIONS.md)

### Tests from `pointwise_conv_unified/test.py`

| Test | Now covered by |
|---|---|
| `test_case[default]` | `bazel test //kernels/convolutions:pointwise_conv_unified`, `test_case[default-fp32]` |
| `test_case[<7 sweep points>]` (128 boundary, 144, 256, 96->32 at 32x32, 3x5, 1x1, 160 at 8x8) | `test_case[sweep_128[...]-fp32]` ... `[sweep_layer[...]-fp32]`, each named by its old sweep id |

### Tests from `pointwise_conv_unified_bn_activation/test.py`

| Test | Now covered by |
|---|---|
| `test_case[default]` | `//kernels/convolutions:pointwise_conv_unified_bn_activation`, `test_case[default-fp32]` |
| `test_case[negative_bias]` (every output exactly 0) | `test_case[negative_bias-fp32]`, plus `kernels/convolutions/pointwise_conv_tpl/test_pointwise_conv.py::test_relu_writes_exact_zeros_for_a_negative_bias` (as E07-17's `test_conv_universal.py`) |
| `test_case[<7 sweep points>]` | `test_case[sweep_*[...]-fp32]` |

### Tests from `depthwise_conv_universal/test.py`

| Test | Now covered by |
|---|---|
| `test_case[default]` | `//kernels/convolutions:depthwise_conv_universal`, `test_case[default-fp32]` |
| `test_case[negative_outputs]` (every output < 0) | `test_case[negative_outputs-fp32]`, plus `depthwise_conv_tpl/test_depthwise_conv.py::test_without_relu_every_negative_sum_stays_negative` |
| `test_case[channels=...]` (9 points) | `test_case[c28_16-fp32]` ... `[c3_5x128-fp32]` |

### Tests from `depthwise_conv_universal_bn_activation/test.py`

| Test | Now covered by |
|---|---|
| `test_case[default]`, `[channels=...]` (9 points) | `//kernels/convolutions:depthwise_conv_universal_bn_activation`, `test_case[...]` |
| `test_case[negative_bias]` | `test_case[negative_bias-fp32]`, plus `test_depthwise_conv.py::test_relu_writes_exact_zeros_for_a_negative_bias` |

The four `benchmark.py` files: the templates' `[benchmark]`.

### Tests moved out of `convolutions/test.py` (E07-18)

| Test | Now covered by |
|---|---|
| `test_resolve[overrides2-depthwise_conv_universal]`, `[overrides3-depthwise_conv_universal_bn_activation]` | `kernels/convolutions/test_routing.py::test_bias_and_relu_choose_the_depthwise_kernel` (all four rows, the (F, T) refusal included; verified) |
| `test_resolve[overrides7-pointwise_conv_unified]`, `[overrides8-pointwise_conv_unified_bn_activation]` | `test_routing.py::test_bias_and_relu_choose_the_pointwise_kernel` (four rows; (F, T) -> bn, zero bias) |
| `test_relu_twins_are_reached_through_an_explicit_description` | `kernels/convolutions/test_layers.py` (E07-16's `from_torch_conv2d(..., apply_relu=True)`): the depthwise bn entry |
| `test_refusals` rows 8-13: width 129 pointwise, stride 2 1x1, groups 8 1x1, `multiple of 8`, `multiple of 4`, a biased 1x1 without ReLU | `test_routing.py::test_pointwise_refusals`. The reason texts change: `width = 129 is above its max 128`, `in_channels = 6 is below its min 8` (6 < 8), `has_bias = True is not one of [False]`. The test's substrings must be rewritten |
| `test_pointwise_pad_shape_refuses_width_over_128` | dropped: `pointwise_pad_shape` is deleted. `width max = 128` refuses first, and `chunked` raises `ValueError` on a shape it cannot pad |

Left for E07-19: `test_resolve` stride-2 and wide384 rows,
`test_width_routing_boundaries`, `test_output_shape_is_derived_for_stride2`
(see its NOTES).

## Open questions (need a decision)

- **OQ1, the pointwise bias region's `when`.** A `when` is one bool parameter
  or its negation, so it cannot say `has_bias or apply_relu`. Pointwise
  therefore seeds on `apply_relu` (`b`: `when = "apply_relu"`), which is exact
  for today's two entries. The cost: E07-20's `pointwise_conv_unified_bias`
  (`has_bias` without ReLU) needs either `when` with `or` (a conditions-grammar
  change) or a program bool parameter (two parameter sets). Depthwise and
  conv_universal have no such problem: their bias sits inside the filters
  tensor.
- **P1, LR presets vs `compare_setup`.** The programs read LRs that nothing
  writes: pointwise reads LR0 and LR7, and wide384 (E07-19) reads LR0 and
  LR2-LR5. Today they run on reset zeros. With poisoned registers,
  `compare_legacy` needs them preset; then `compare_setup` reports each one
  (old 0xA5A5, new 0), although the old `setup()` wrote none. Either accept
  these as the PR's listed, expected differences (what `_check/` does), or
  have `compare_setup` ignore a register that only the new side writes, at
  value 0.
- **OQ2, cross-parameter domains.** `groups == in_channels == out_channels`
  becomes four whole-ratio `[derived]` checks. Routing is right, but the
  refusal now reads "'groups / in_channels' is 1/2, not a whole number".
- **OQ3, depthwise cost 1.** This keeps today's C = 1 answer. A later
  depthwise entry must also cost more than conv_universal's.
- **OQ4, routing-visible `fpb`.** It is not `query_required`, and each entry
  fixes it, so queries never name it.

## Latent bugs (noted, not fixed)

- **B1, the depthwise chunk count rounds down** (DW :180) while the packer
  rounds up (convolutions/app.py:195). This happens when `rows * cols` is not
  a multiple of 128, e.g. height 17 at width 16: the input overruns into the
  kernel region and teardown fails (found by reading, not run). The template
  keeps `num_chunks` floor, as conv_universal_tpl does, while
  `chunked`/`chunked_guard` round up. No case hits it; refusing those shapes
  is a separate routing change.
- **B2, pointwise weights are silently truncated** when the file is oversize
  (PW :208-209, :190-192). `pack` now checks the exact shape (L15), so
  oversize data is refused; that change is its own issue (checklist step 8).
- **B3, the input overrun at height 17 / width 16** is B1.
