"""DRAFT (E07-18) checker: build a merged template .asm from an old twin pair.

Read-only on the repo. Usage: build_asm.py <plain.asm> <bn.asm> <out.asm> <crmap> <header-title> <cond>

* Every old '#' comment is dropped from the code; the plain file's leading
  '#' block becomes the {#- ... -#} header (Q79: notes live in the header).
* ACTIVATE.QUANTIZE identity/relu -> ACTIVATE.QUANTIZE {{ 'relu' if apply_relu else 'identity' }}.
* Raw CR numbers (CR2..CR14, and CR15 where mapped) -> {{ cr.<name> }} by the
  [abi] map; CR0/CR1 stay literal (hardwired), except names mapped for CR0.
* The comment-stripped code of the two files is diffed line by line; each
  differing hunk becomes {%- if <cond> %} <bn lines> {%- else %} <plain lines> {%- endif %}.
* Mnemonics are upper-cased with tools/upper_mnemonics.py (binary-identical by E07-01).
"""

import difflib
import re
import sys
from pathlib import Path

sys.path.insert(0, "/home/user/ipu-emulator/tools")
from upper_mnemonics import upper_text  # noqa: E402

plain_path, bn_path, out_path, crmap_arg, title, cond = sys.argv[1:7]  # cond: the Jinja test of the bn variant
CRMAP = dict(item.split("=") for item in crmap_arg.split(","))  # "2=mask,3=y,..."


def header_and_code(path):
    lines = Path(path).read_text().splitlines()
    head = []
    i = 0
    while i < len(lines) and (lines[i].startswith("#") or not lines[i].strip()):
        head.append(lines[i][1:].removeprefix(" ") if lines[i].startswith("#") else "")
        i += 1
    code = []
    for line in lines[i:]:
        text = line.split("#", 1)[0].rstrip()
        if text.strip():
            code.append(text)
    return head, code


def rename(line):
    line = re.sub(r"ACTIVATE\.QUANTIZE\s+(identity|relu)", "ACTIVATE.QUANTIZE {{ activation }}", line,
                  flags=re.I)

    def cr(m):
        n = m.group(1)
        return "{{ cr.%s }}" % CRMAP[n] if n in CRMAP else "CR" + n

    return re.sub(r"\b[cC][rR](\d+)\b", cr, line)


head, plain = header_and_code(plain_path)
_, bn = header_and_code(bn_path)
plain = [rename(x) for x in plain]
bn = [rename(x) for x in bn]
norm = lambda s: re.sub(r"\s+", " ", s.strip()).lower()  # noqa: E731
sm = difflib.SequenceMatcher(a=[norm(x) for x in plain], b=[norm(x) for x in bn], autojunk=False)
out = []
hunks = 0
for tag, i1, i2, j1, j2 in sm.get_opcodes():
    if tag == "equal":
        out += plain[i1:i2]
        continue
    hunks += 1
    if j2 == j1:  # only the plain variant has these lines
        out += ["{%- if not seeded %}", *plain[i1:i2], "{%- endif %}"]
        continue
    out.append("{%- if seeded %}")
    out += bn[j1:j2]
    if i2 > i1:
        out.append("{%- else %}")
        out += plain[i1:i2]
    out.append("{%- endif %}")

header = "{#- " + title + "\n\n" + "\n".join("    " + h if h else "" for h in head).rstrip() + "\n-#}\n"
prelude = (
    "{#- The variants (../registry.toml): seeded = the bias-seed program; the activation follows apply_relu. -#}\n"
    "{%- set seeded = " + cond + " -%}\n"
    '{%- set activation = "relu" if apply_relu else "identity" -%}\n'
)
text, n = upper_text(header + prelude + "\n".join(out) + "\n")
Path(out_path).write_text(text)
print(f"{out_path}: {hunks} bias hunks, {n} tokens upper-cased")
