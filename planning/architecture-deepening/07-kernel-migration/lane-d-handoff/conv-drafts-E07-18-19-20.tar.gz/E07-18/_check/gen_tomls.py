"""Write the E07-18 kernel.toml drafts (cases are verbose: every query parameter is
query_required and has no default, as conv_universal_tpl, so each case names all of them)."""
import sys
from pathlib import Path
D = Path(sys.argv[1])

def case(name, comment, values, gen):
    lines = [f"[cases.{name}]" + (f"  # {comment}" if comment else "")]
    lines += [f"{k} = {v}" for k, v in values.items()]
    lines.append(f'generator = "../gen.py:{gen}"  # the ipu_apps data, for the proof')
    return "\n".join(lines) + "\n"

def b(v):
    return "true" if v else "false"

# ---------------------------------------------------------------- pointwise
PW_GEOM = dict(kernel_size=1, dilation=1, padding=0, stride=1, groups=1)
def pw(i, o, h, w, relu, axes=False):
    f = (lambda v: f"[{v}]") if axes else (lambda v: v)
    return dict(in_channels=f(i), out_channels=f(o), height=f(h), width=f(w), **PW_GEOM,
                has_bias=b(relu), apply_relu=b(relu))
pw_cases = [
    case("default", "PW/BN cases.py DEFAULTS; the bn twin's has_bias/apply_relu (pointwise_conv_unified fixes both false)", pw(16, 8, 16, 16, True), "legacy_pointwise"),
    case("negative_bias", "BN cases.py:10-12: zero weights, a bias below zero, so ReLU writes zeros; bn entry only", pw(8, 8, 16, 16, True), "legacy_pointwise_negative_bias"),
]
for n, (i, o, h, w, c) in {"sweep_128": (128, 8, 16, 16, "single pass, the 128 boundary"),
                           "sweep_144": (144, 8, 16, 16, "multi-pass: 1 full + a tail of 16"),
                           "sweep_256": (256, 8, 16, 16, "multi-pass, no tail"),
                           "sweep_96x32": (96, 32, 32, 32, "larger spatial and out_channels"),
                           "sweep_3x5": (144, 8, 3, 5, "non-power-of-2 spatial: pads to 16 x 8"),
                           "sweep_1x1": (8, 4, 1, 1, "degenerate 1x1 spatial: pads to 128 x 1"),
                           "sweep_layer": (160, 160, 8, 8, "the end-to-end layer shape")}.items():
    pw_cases.append(case(n, c, pw(i, o, h, w, True, axes=True), "legacy_pointwise"))

PW = '''# DRAFT (E07-18): kernels/convolutions/pointwise_conv_tpl/kernel.toml
# The template of the pointwise 1x1 convolution, FP32 wide vectors. Its variants
# are the entries pointwise_conv_unified and pointwise_conv_unified_bn_activation
# in ../registry.toml. One parameter set, as conv_universal_tpl: the program
# reads apply_relu itself (the bias seed and ReLU; see the .asm header).
# Old sources (under src/tools/ipu-apps/src/ipu_apps/kernels/convolutions/):
# PW = pointwise_conv_unified/app.py, BN = pointwise_conv_unified_bn_activation/app.py.
[kernel]
op = "conv2d"
formats = ["fp32"]

# The universal vocabulary, every parameter query_required (the ipu_apps
# requires), in the old supports' order (PW app.py:280-303).
[params]
in_channels  = { type = "int", min = 8, multiple_of = 8, query_required = true }   # PW app.py:97, :291
out_channels = { type = "int", min = 4, multiple_of = 4, query_required = true }   # PW app.py:99, :293
height       = { type = "int", min = 1, query_required = true }
width        = { type = "int", min = 1, max = 128, query_required = true }         # PW app.py:295
kernel_size  = { type = "int", choices = [1], query_required = true }
dilation     = { type = "int", choices = [1], query_required = true }
padding      = { type = "int", choices = [0], query_required = true }
stride       = { type = "int", choices = [1], query_required = true }
groups       = { type = "int", choices = [1], query_required = true }
has_bias     = { type = "bool", query_required = true }
apply_relu   = { type = "bool", query_required = true }

# PW app.py:115-141 and setup() :224-261.
[derived]
# pointwise_pad_shape (convolutions/app.py:466-484): cols is the smallest divisor
# of 128 >= width, the next power of 2; min(1, max(0, width - t)) is 1 when width > t.
cols                = "1 + min(1, max(0, width - 1)) + 2 * min(1, max(0, width - 2)) + 4 * min(1, max(0, width - 4)) + 8 * min(1, max(0, width - 8)) + 16 * min(1, max(0, width - 16)) + 32 * min(1, max(0, width - 32)) + 64 * min(1, max(0, width - 64))"
row_groups          = "ceil(height * cols / 128)"           # chunks per channel (PW app.py:134)
rows                = "row_groups * 128 / cols"              # the padded height, for the family's chunked transform
num_passes          = "ceil(in_channels / 128)"              # written, never read by the program
tail_size           = "in_channels - (num_passes - 1) * 128" # written, never read
pipeline_limit_full = "128 - 5"
pipeline_limit_tail = "tail_size - 5"                        # may be negative (two's complement)
last_pass           = "num_passes - 1"
fixed_idx_step      = "128"                                  # lane space (Half B)
pass_stride         = "128"                                  # 128 input channels = 128 rows

# Placed in the old harness's order (PW app.py:150-157, BN app.py:163-171):
# input, weights, mask, [bias,] output.
[inputs.x]
shape = ["in_channels", "height", "width"]
pack = "chunked"                             # padded to rows x cols, chunk-interleaved (no headroom)
row = 0                                      # read through CR0 (PW app.py:218-220)

[inputs.w]
shape = ["out_channels", "in_channels", 1, 1]
pack = "conv_weight_groups"                  # E07-16's: 128 input channels a row = PW _pack_kernel (app.py:164-194)

# The bias region exists exactly when the program is seeded: apply_relu here.
# when cannot say "has_bias or apply_relu" (one bool parameter or its negation),
# and today's two kernels need no more (NOTES.md, OQ1).
[inputs.b]
shape = ["out_channels"]
pack = "pass0_bias"                          # BN _pack_bias (app.py:209-225): out * num_passes rows
when = "apply_relu"

[scratch.mask]                               # 16 bytes of 0xFF, the rest of the row zero (PW app.py:216)
shape = [1, 128]
after = "w"
bytes = "../masks.py:keep_all_mask"

[outputs.y]
shape = ["out_channels", "height", "width"]
pack = "chunked"

# Every CR the ipu_apps setup() wrote (CR2-CR15, CR0 read as the input base; no LR).
[abi]
x                   = "CR0"
mask                = "CR2"
y                   = "CR3"
num_passes          = "CR4"
row_groups          = "CR5"
pipeline_limit_full = "CR6"
out_channels        = "CR7"
in_channels         = "CR8"     # the row-group stride
pipeline_limit_tail = "CR9"
b                   = "CR10"    # BN app.py:268 (b's when = "apply_relu")
tail_size           = { register = "CR10", when = "not apply_relu" }   # PW app.py:241
last_pass           = "CR11"
fixed_idx_step      = "CR12"
pass_stride         = "CR13"
w                   = "CR14"
# CR15: the default dstructure (PW app.py:261).
# LR0: the program reads it as the input row-group base without setting it
# (today's reset 0). See NOTES.md, P1 (poisoned registers).

[golden]
op = "conv2d"                          # x, w [out, in, 1, 1], b when present; apply_relu selects ReLU
tolerance = { fp32 = "FP32_LONG" }     # K reaches 256 (sweep_256); TO MEASURE

# The two ipu_apps kernels' cases and test sweeps (each entry chooses its own).
# A sweep point of one value per axis is named <case>[in_channels=..,...,width=..],
# its old sweep id.

''' + "\n".join(pw_cases) + '''
# PW/BN benchmark.py CONFIGS (identical), MAX_CYCLES = 200_000_000.
[benchmark]
max_cycles = 200_000_000
points = [
  { height = 128, width = 128, in_channels = 64,  out_channels = 32 },
  { height = 128, width = 128, in_channels = 32,  out_channels = 48 },
  { height = 64,  width = 64,  in_channels = 128, out_channels = 64 },
  { height = 64,  width = 64,  in_channels = 64,  out_channels = 128 },
  { height = 32,  width = 32,  in_channels = 256, out_channels = 96 },
  { height = 32,  width = 32,  in_channels = 96,  out_channels = 256 },
  { height = 16,  width = 16,  in_channels = 384, out_channels = 128 },
  { height = 16,  width = 16,  in_channels = 128, out_channels = 256 },
]
'''
(D / "pointwise_conv_tpl/kernel.toml").write_text(PW)

# ---------------------------------------------------------------- depthwise
def dw(c, h, w, bn):
    return dict(in_channels=c, out_channels=c, height=h, width=w, kernel_size=3, dilation=1, padding=1,
                stride=1, groups=c, has_bias=b(bn), apply_relu=b(bn), fpb=25 if bn else 28)
dw_cases = [
    case("default", "DW/DB cases.py DEFAULTS, the plain twin's values (the bn entry fixes its own)", dw(4, 16, 16, False), "legacy_depthwise"),
    case("negative_outputs", "DW cases.py:10: weights -1 on input 5, every sum negative; plain entry only", dw(4, 16, 16, False), "legacy_depthwise_negative"),
    case("negative_bias", "DB cases.py:10-13: zero weights, bias below zero, ReLU writes zeros; bn entry only", dw(4, 16, 16, True), "legacy_depthwise_negative_bias"),
]
for n, (c, h, w, bn, note) in {
        "c28_16": (28, 16, 16, False, "one full FPB = 28 super-block (plain)"),
        "c25_16": (25, 16, 16, True, "one full FPB = 25 super-block (bn)"),
        "c32_16": (32, 16, 16, False, "one full + one partial super-block (both)"),
        "c16_32": (16, 32, 32, False, "multi-chunk, partial super-block (both)"),
        "c50_64": (50, 64, 64, False, "two super-blocks, larger spatial (both)"),
        "c4_8x128": (4, 8, 128, False, "cols = 128, P0 (both)"),
        "c30_16x128": (30, 16, 128, False, "cols = 128, multi-chunk, block spanning (both)"),
        "c4_8x8": (4, 8, 8, False, "padding-heavy (both)"),
        "c4_5x5": (4, 5, 5, False, "padding-heavy (both)"),
        "c3_5x128": (3, 5, 128, False, "end-to-end layer shape (plain)"),
        "c4_6x65": (4, 6, 65, True, "end-to-end layer shape, width 65 -> cols 128 (bn)")}.items():
    dw_cases.append(case(n, note, dw(c, h, w, bn), "legacy_depthwise"))

DWT = '''# DRAFT (E07-18): kernels/convolutions/depthwise_conv_tpl/kernel.toml
# The template of the depthwise 3x3 stride-1 "same" convolution, FP32 wide
# vectors. Its variants are the entries depthwise_conv_universal and
# depthwise_conv_universal_bn_activation in ../registry.toml. It is also stage 1
# of the depthwise_conv_stride2_* kernels (E07-19), so its program reads only
# names those kernels declare too: has_bias, apply_relu and the [abi] names
# below. The program reads has_bias/apply_relu itself (seeded = has_bias or
# apply_relu, as conv_universal_tpl). Old sources: DW = depthwise_conv_universal/app.py,
# DB = depthwise_conv_universal_bn_activation/app.py.
[kernel]
op = "conv2d"
formats = ["fp32"]
# At in_channels = out_channels = groups = 1 a depthwise 3x3 is also a plain
# one: today's resolve answers conv_universal (this kernel an alternative), so
# this costs more than conv_universal_tpl's entries (an equal cost would be a
# tie, an error).
cost = 1

[params]
in_channels  = { type = "int", min = 1, query_required = true }
out_channels = { type = "int", min = 1, query_required = true }               # == in_channels ([derived] checks)
height       = { type = "int", min = 1, query_required = true }
width        = { type = "int", min = 1, max = 128, query_required = true }     # DW app.py:359
kernel_size  = { type = "int", choices = [3], query_required = true }
dilation     = { type = "int", choices = [1], query_required = true }
padding      = { type = "int", choices = [1], query_required = true }
stride       = { type = "int", choices = [1], query_required = true }         # 2: depthwise_conv_stride2_*
groups       = { type = "int", min = 1, query_required = true }               # == in_channels ([derived] checks)
has_bias     = { type = "bool", query_required = true }
apply_relu   = { type = "bool", query_required = true }
# Not a query parameter: channels per 256-element super-block, 28 unseeded
# (9 taps, DW app.py:91) or 25 seeded (bias + 9 taps, DB app.py:97). It is CR7,
# a register value, and a bool cannot enter an expression (params._derived
# passes ints only), so it cannot be derived from has_bias/apply_relu: each
# entry fixes it (no default, so the entry's value stands in), and the
# depthwise_filters transform refuses an fpb that does not match the seed.
fpb          = { type = "int", choices = [25, 28] }

[derived]
# groups == in_channels == out_channels has no [params] form: each ratio must be whole.
groups_per_in = "groups / in_channels"
in_per_groups = "in_channels / groups"
out_per_in    = "out_channels / in_channels"
in_per_out    = "in_channels / out_channels"
cols          = "16 + 16 * min(1, max(0, width - 16)) + 32 * min(1, max(0, width - 32)) + 64 * min(1, max(0, width - 64))"
rows          = "max(height, ceil(256 / cols))"            # at least 2 chunks
num_chunks    = "rows * cols // 128"                       # rounds down, as before (NOTES.md B1)
kernel_rows   = "ceil(in_channels / fpb) * 2"              # written, never read
ring_adv      = "3 * 128"                                  # R_CYCLIC elements
chunk_limit   = "(num_chunks - 1) * in_channels + in_channels"
slot_stride   = "128"
half_slot     = "256"
walk_step     = "256 - 2 * cols - 2"                       # -2 at cols 128: two's complement
dstructure    = "dstructure(128, 128 // cols - cols // 128)"

# Placed in the old harness's order (DW app.py:207-215): input (with its
# headroom), filters, mask, output.
[inputs.x]
shape = ["in_channels", "height", "width"]
pack = "chunked_guard"

# One region holds each channel's bias and taps (Q83), so one tensor: column 0
# the bias, then the 9 taps (DB's order, app.py:129-130). Column 0 is stored
# only when seeded (DW's slot is the 9 taps).
[inputs.filters]
shape = ["in_channels", 10]
pack = "depthwise_filters"

[scratch.border_mask]
shape = [1, 128]
after = "filters"
bytes = "../masks.py:border_mask"

[outputs.y]
shape = ["out_channels", "height", "width"]
pack = "chunked"

# Every CR the ipu_apps setup() wrote (CR2-CR15; no LR).
[abi]
y           = { register = "CR2", offset = -1 }   # output base - 1: the deferred store (DW app.py:286)
border_mask = "CR3"
cols        = "CR4"
filters     = "CR5"
in_channels = "CR6"     # the group stride
fpb         = "CR7"
kernel_rows = "CR8"
ring_adv    = "CR9"
x           = "CR10"    # the region base, headroom included
chunk_limit = "CR11"
slot_stride = "CR12"
half_slot   = "CR13"
walk_step   = "CR14"
dstructure  = "CR15"

[golden]
reference = "reference.py:reference"   # filters split, then the shared conv2d (groups = channels)
tolerance = { fp32 = "FP32_ORDER" }     # 9 taps + bias; TO MEASURE

''' + "\n".join(dw_cases) + '''
# DW/DB benchmark.py CONFIGS as one union (PER = "channels", MAX_CYCLES = 50_000_000).
[benchmark]
per = "in_channels"
max_cycles = 50_000_000
points = [
''' + "".join(f"  {{ height = {h}, width = {w}, in_channels = {c}, out_channels = {c}, groups = {c} }},\n"
              for h, w, c in ((16, 16, 8), (16, 16, 25), (16, 16, 26), (16, 16, 28), (16, 16, 29), (32, 32, 16),
                              (32, 32, 32), (32, 32, 50), (32, 32, 56), (64, 64, 32), (64, 64, 64), (32, 32, 96),
                              (16, 16, 40))) + "]\n"
(D / "depthwise_conv_tpl/kernel.toml").write_text(DWT)
print("written")
