#!/bin/sh
# Throwaway validation tree for the E07-18 drafts (nothing in the repo is touched).
D=/tmp/claude-0/-home-user-ipu-emulator/54c27a5c-a602-5113-867c-87a759940cf5/scratchpad/conv-drafts
C=$D/E07-18/_check
rm -rf $C/tree $C/pylib; mkdir -p $C/tree/convolutions $C/pylib
cp -r $D/E07-18/pointwise_conv_tpl $D/E07-18/depthwise_conv_tpl $C/tree/convolutions/
cat $D/E07-17/pack.py $D/E07-18/convolutions/pack_additions.py > $C/tree/convolutions/pack.py
cat $D/E07-17/gen.py $D/E07-18/convolutions/gen_additions.py > $C/tree/convolutions/gen.py
cp $D/E07-18/convolutions/registry_additions.toml $C/tree/convolutions/registry.toml
cp -r /home/user/ipu-emulator/src/tools/ipu-kernels/src/ipu_kernels $C/pylib/
mkdir -p $C/pylib/ipu_kernels/convolutions; touch $C/pylib/ipu_kernels/convolutions/__init__.py
cp $D/E07-17/_family/ipu_kernels/convolutions/masks.py $C/pylib/ipu_kernels/convolutions/
# no torch in this interpreter: drop the references (compare_setup and digests do not need them)
for k in pointwise_conv_tpl depthwise_conv_tpl; do
  rm $C/tree/convolutions/$k/reference.py
  sed -i '/^reference = /d' $C/tree/convolutions/$k/kernel.toml
  sed -i '/^\[benchmark\]/,$d' $C/tree/convolutions/$k/kernel.toml
done
# E07-17's template and entries, for the cross-template routing check
cp -r $D/E07-17/conv_universal_tpl $C/tree/convolutions/
rm $C/tree/convolutions/conv_universal_tpl/reference.py
sed -i '/^reference = /d' $C/tree/convolutions/conv_universal_tpl/kernel.toml
sed -i '/^\[benchmark\]/,$d' $C/tree/convolutions/conv_universal_tpl/kernel.toml
grep -v '^#' $D/E07-17/registry.toml >> $C/tree/convolutions/registry.toml
