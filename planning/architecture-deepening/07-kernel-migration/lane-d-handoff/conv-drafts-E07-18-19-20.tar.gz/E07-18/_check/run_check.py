"""E07-18 draft check: every entry's programs vs the E02 asm digest, and compare_setup
(CRs, LRs, XMEM after setup) for every legacy case of the four kernels."""
import hashlib, json, sys, tempfile
from pathlib import Path
from compare_setup import compare_setup
from migration import legacy_case_ids
from ipu_harness.registry import Registry
from ipu_harness.cases import expand
from ipu_harness.params import plan_case
from ipu_harness.assembly import assemble
from ipu_as import lark_tree
from ipu_isa.formats import ElementFormat

T = Path(__file__).parent / "tree"
digests = json.load(open("/home/user/ipu-emulator/src/tools/ipu-apps/test/baselines/asm_digests.json"))
reg = Registry.load(T)
if reg.invalid:
    for k, v in reg.invalid.items():
        print("INVALID", k, v)
    sys.exit(1)

DW = {"channels=28,height=16,width=16": "c28_16", "channels=25,height=16,width=16": "c25_16",
      "channels=32,height=16,width=16": "c32_16", "channels=16,height=32,width=32": "c16_32",
      "channels=50,height=64,width=64": "c50_64", "channels=4,height=8,width=128": "c4_8x128",
      "channels=30,height=16,width=128": "c30_16x128", "channels=4,height=8,width=8": "c4_8x8",
      "channels=4,height=5,width=5": "c4_5x5", "channels=3,height=5,width=128": "c3_5x128",
      "channels=4,height=6,width=65": "c4_6x65"}
ok = True
for name in sys.argv[1:] or ["pointwise_conv_unified", "pointwise_conv_unified_bn_activation",
                             "depthwise_conv_universal", "depthwise_conv_universal_bn_activation"]:
    m = reg.kernel(name)
    key = f"src/tools/ipu-apps/src/ipu_apps/kernels/convolutions/{name}/{name}.asm"
    bins = set()
    for case in expand(m):
        plan = plan_case(m, case.values, ElementFormat.FP32, case=case.decl)
        prog = assemble(plan)
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / "p.bin"
            lark_tree.assemble_to_bin_file(prog.rendered, str(p))
            bins.add(hashlib.sha256(p.read_bytes()).hexdigest())
    want = digests[key]["bin_sha256"]
    same = bins == {want}
    ok &= same
    print(f"{name}: {len(list(expand(m)))} cases, program digests {'EQUAL E02' if same else 'DIFFERENT ' + str(bins)}")
    for cid in legacy_case_ids(name):
        rep = compare_setup(name, name, cid, case_map=DW, root=T)
        # pointwise: LR0/LR7 are preset to 0 (the program reads them unset), the old side poisoned
        expected = {"LR0: old 42405, new 0", "LR7: old 42405, new 0"} if name.startswith("pointwise") else set()
        same = not rep.xmem_total and set(rep.registers) <= expected
        verdict = "IDENTICAL" if rep.identical else ("IDENTICAL but " + ", ".join(rep.registers) + " (expected presets)" if same else "DIFFERENT")
        print(f"  {cid:48s} -> {rep.new:75s} {verdict} ({rep.xmem_bytes} B)")
        if not same:
            print(rep.describe()); ok = False
print("ALL OK" if ok else "FAILURES")
