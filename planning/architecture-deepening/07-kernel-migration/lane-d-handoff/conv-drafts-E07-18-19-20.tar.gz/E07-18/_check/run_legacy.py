"""compare_legacy rows (binary, raw output bytes vs the old XMEM, cycles) for the E07-18 kernels."""
from pathlib import Path
from compare_legacy import compare_kernel
from ipu_harness.registry import Registry

DW = {f"channels={c},height={h},width={w}": n for n, (c, h, w) in {
    "c28_16": (28, 16, 16), "c25_16": (25, 16, 16), "c32_16": (32, 16, 16), "c16_32": (16, 32, 32),
    "c50_64": (50, 64, 64), "c4_8x128": (4, 8, 128), "c30_16x128": (30, 16, 128), "c4_8x8": (4, 8, 8),
    "c4_5x5": (4, 5, 5), "c3_5x128": (3, 5, 128), "c4_6x65": (4, 6, 65)}.items()}
reg = Registry.load(Path(__file__).parent / "tree")
print("| kernel | case | binary | output | cycles old/new | notes |\n|---|---|---|---|---|---|")
for name in ("pointwise_conv_unified", "pointwise_conv_unified_bn_activation",
             "depthwise_conv_universal", "depthwise_conv_universal_bn_activation"):
    for r in compare_kernel(name, reg.kernel(name), DW):
        print(f"| {r.kernel} | {r.case} | {'yes' if r.binary_ok else 'NO'} | {'yes' if r.output_ok else 'NO'} | {r.cycles_old}/{r.cycles_new} | {'; '.join(r.notes)} |")
