"""Routing answers of the four E07-18 entries for every (has_bias, apply_relu) combination."""
from pathlib import Path
from ipu_harness.registry import Registry
reg = Registry.load(Path(__file__).parent / "tree")
base = dict(kernel_size=1, stride=1, padding=0, dilation=1, groups=1, in_channels=8, out_channels=8, height=8, width=8)
dw = dict(kernel_size=3, stride=1, padding=1, dilation=1, groups=4, in_channels=4, out_channels=4, height=8, width=8)
for label, q in (("pointwise", base), ("depthwise", dw)):
    for hb in (False, True):
        for ar in (False, True):
            v = reg.resolve("conv2d", **q, has_bias=hb, apply_relu=ar)
            print(f"{label:9s} has_bias={hb!s:5s} apply_relu={ar!s:5s} -> {v.kernel.name if v else 'refused'}")
for q in (dict(dw, groups=2), dict(dw, out_channels=8), dict(base, width=129), dict(base, in_channels=6)):
    v = reg.resolve("conv2d", **q, has_bias=False, apply_relu=False)
    print("refusal:", bool(v), v.reason[:230])
for hb, ar in ((False, False), (True, True), (False, True)):
    q = dict(kernel_size=3, stride=1, padding=1, dilation=1, groups=1, in_channels=1, out_channels=1, height=16, width=16)
    v = reg.resolve("conv2d", **q, has_bias=hb, apply_relu=ar)
    print(f"C=1 3x3 has_bias={hb} apply_relu={ar} -> {v.kernel.name if v else 'refused'} alternatives {v.alternatives if v else ''}")
