"""The 7e0e0fd9 trap, on the drafts: seeded without a bias (has_bias = false,
apply_relu = true), the seeded generator's bias values are nonzero, and the
packed bias the program reads must be zero."""
from pathlib import Path
import numpy as np
from ipu_harness.cases import expand
from ipu_harness.registry import Registry
from ipu_harness.runner import stage
from ipu_isa.formats import ElementFormat
reg = Registry.load(Path(__file__).parent / "tree")
for kernel, tensor in (("pointwise_conv_unified_bn_activation", "b"), ("depthwise_conv_tpl", "filters")):
    m = reg.kernel(kernel)
    case = next(c for c in expand(m) if c.name == "relu_no_bias")
    s = stage(m, case, ElementFormat.FP32)
    gen = np.asarray(s.inputs[tensor])
    start, size = s.region_bytes(tensor)
    rows = np.frombuffer(s.model.read_xmem(start, size), np.float32).reshape(-1, 128)
    if tensor == "b":
        read = rows[:: s.plan.derived["num_passes"], 0]
        gcol = gen
    else:  # 25-channel blocks of 10-element slots, the bias at element 10 s
        blocks = rows.reshape(-1, 256)[:, :250].reshape(-1, 10)[: gen.shape[0]]
        read, gcol = blocks[:, 0], gen[:, 0]
    print(f"{kernel}: generated bias nonzero {bool(np.any(gcol != 0))}, packed bias all zero {bool(np.all(read == 0))}")
