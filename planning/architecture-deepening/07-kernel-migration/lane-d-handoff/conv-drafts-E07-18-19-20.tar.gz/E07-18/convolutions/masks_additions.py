"""DRAFT (E07-18/19): additions to kernels/convolutions/masks.py (E07-16's
``first_layer_mask``, E07-17's ``border_mask``, which the depthwise template
reuses: build_border_mask_blob, DW app.py:256). ``bytes = "../masks.py:<fn>"``."""


def keep_all_mask(plan: CasePlan) -> bytes:
    """The pointwise kernels' R_MASK: slot 0 keeps every lane (PW app.py:212-216,
    16 bytes of 0xFF), the rest of the row zero; the program never masks."""
    blob = bytearray(FORMATS[plan.format].row_bytes)
    blob[:16] = b"\xff" * 16
    return bytes(blob)


def wide_mask(plan: CasePlan) -> bytes:
    """conv_universal_wide384's R_MASK (W app.py:83-113): slot 0 keeps every lane,
    slot 1 zeros every lane (vertical border), slot 2 zeros lane 0 (left edge),
    slot 3 zeros lane 127 (right edge); then zeros."""
    blob = bytearray(FORMATS[plan.format].row_bytes)
    for slot in (0, 2, 3):
        blob[slot * 16 : slot * 16 + 16] = b"\xff" * 16
    blob[2 * 16 + 0] &= ~0x01  # slot 2, lane 0
    blob[3 * 16 + 15] &= ~0x80  # slot 3, lane 127
    return bytes(blob)
