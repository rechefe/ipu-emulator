"""DRAFT (E07-18): additions to kernels/convolutions/pack.py (E07-16's file, with
E07-17's ``chunked``, ``chunked_guard`` and ``fpb28_filters``). Appended after
it: uses its ``_ceil``, ``LANES``, ``np`` and ``CasePlan``.

The pointwise and depthwise kernels reuse the family's transforms:
``chunked`` (pointwise x and y, depthwise y: padded to ``[derived] rows`` x
``cols``, chunk-interleaved), ``chunked_guard`` (depthwise x, with the
``in_channels`` headroom rows) and E07-16's ``conv_weight_groups`` (pointwise
w: 128 input channels a row = PW ``_pack_kernel``). New here:

* ``pass0_bias`` -- BN ``_pack_bias`` (app.py:209-225): ``(out,)`` to ``out *
  num_passes`` rows (a grid mirroring the weights), the bias at lane 0 of row
  ``oc * num_passes``. ``rows(shape, plan)`` reads ``[derived] num_passes``.
* ``depthwise_filters`` -- DW ``_pack_depthwise_kernel`` (app.py:97-120) and DB
  ``_pack_depthwise_kernel_bias`` (app.py:103-131): ``(channels, 10)``, column 0
  the bias, then the 9 taps. Seeded (``has_bias or apply_relu``, as the program
  decides), each channel's slot is all 10 and 25 channels share a 256-element
  super-block (2 rows); unseeded, the slot is the 9 taps, 28 to a block, and
  column 0 is not stored. The kernel's ``fpb`` must agree.
"""


class Pass0Bias:
    """``(out,)`` as ``out * num_passes`` rows, the bias at lane 0 of each output
    channel's first row (its pass-0 block)."""

    @staticmethod
    def _check(shape: tuple[int, ...]) -> None:
        if len(shape) != 1:
            raise ValueError(f"pass0_bias lays out (out_channels,), not {shape}")

    def rows(self, shape: tuple[int, ...], plan: CasePlan) -> int:
        """``out * num_passes`` rows.

        Raises:
            ValueError: Not one dimension.
        """
        self._check(shape)
        return shape[0] * int(plan.derived["num_passes"])

    def to_rows(self, a: Array, plan: CasePlan) -> Array:
        """``a`` at lane 0 of rows ``0, P, 2P, ...``, every other element zero."""
        self._check(a.shape)
        rows = np.zeros((a.shape[0], int(plan.derived["num_passes"]), LANES), dtype=np.float64)
        rows[:, 0, 0] = a
        return rows.reshape(-1, LANES)

    def from_rows(self, r: Array, plan: CasePlan, shape: tuple[int, ...]) -> Array:
        """Lane 0 of each output channel's first row."""
        return r.reshape(shape[0], int(plan.derived["num_passes"]), LANES)[:, 0, 0].copy()


class DepthwiseFilters:
    """``(channels, 10)``: bias, then 9 taps, per channel, in super-blocks."""

    @staticmethod
    def _layout(shape: tuple[int, ...], plan: CasePlan) -> tuple[int, int]:
        """(first stored column, channels per block)."""
        if len(shape) != 2 or shape[1] != 10:
            raise ValueError(f"depthwise_filters lays out (channels, 10), not {shape}")
        seeded = bool(plan.params["has_bias"] or plan.params["apply_relu"])
        first, fpb = (0, 25) if seeded else (1, 28)
        given = int(plan.params["fpb"] if "fpb" in plan.params else plan.derived["fpb"])  # stride-2: [derived]
        if given != fpb:
            raise ValueError(
                f"depthwise_filters: fpb = {given}, but a "
                f"{'seeded' if seeded else 'plain'} program stores {fpb} channels a block"
            )
        return first, fpb

    def rows(self, shape: tuple[int, ...], plan: CasePlan) -> int:
        """Two rows per super-block of ``fpb`` channels.

        Raises:
            ValueError: Not ``(channels, 10)``, or ``fpb`` disagrees with the seed.
        """
        _, fpb = self._layout(shape, plan)
        return _ceil(shape[0], fpb) * 2

    def to_rows(self, a: Array, plan: CasePlan) -> Array:
        """Each block's channel slots, then zeros."""
        first, fpb = self._layout(a.shape, plan)
        c, slot = a.shape[0], 10 - first
        blocks = _ceil(c, fpb)
        slots = np.zeros((blocks * fpb, slot), dtype=np.float64)
        slots[:c] = a[:, first:]
        out = np.zeros((blocks, 2 * LANES), dtype=np.float64)
        out[:, : fpb * slot] = slots.reshape(blocks, fpb * slot)
        return out.reshape(-1, LANES)

    def from_rows(self, r: Array, plan: CasePlan, shape: tuple[int, ...]) -> Array:
        """The stored columns back; column 0 is zero when unseeded."""
        first, fpb = self._layout(shape, plan)
        c, slot = shape[0], 10 - first
        blocks = _ceil(c, fpb)
        out = np.zeros(shape, dtype=np.float64)
        out[:, first:] = r.reshape(blocks, 2 * LANES)[:, : fpb * slot].reshape(-1, slot)[:c]
        return out


pass0_bias = Pass0Bias()
depthwise_filters = DepthwiseFilters()
