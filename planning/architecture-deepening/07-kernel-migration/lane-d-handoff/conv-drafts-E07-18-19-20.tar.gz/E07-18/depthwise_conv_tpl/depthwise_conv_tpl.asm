{#- depthwise_conv_tpl.asm -- y = act(depthwise conv2d(x, w, 3x3, stride 1, padding 1) [+ b]), FP32 wide vectors.

    Universal Depthwise 3x3 Convolution (no bias, no activation).

    Base app for depthwise_conv_universal_bn_activation. Same walking-pointer /
    rotating cyclic-slot pipeline and deferred-store scheme, minus the two BN
    additions:
      * no per-channel bias seed (r_acc reset happens on tap 1's own product),
      * no ReLU — ACTIVATE.QUANTIZE runs with `identity` (still required: it is
        the only INT8 clamp/quantize step; r_acc is FP-wide internally).

    Per-channel budget: 9 cyc/ch = 9 weight taps, ACTIVATE.QUANTIZE fused into
    tap 9's own cycle. ACTIVATE.QUANTIZE reads r_acc LIVE (see
    execute_activate_quantize), and ACC dispatches before AAQ in the
    per-cycle order, so tap 9's acc.add and ACTIVATE.QUANTIZE co-issue in one
    VLIW word — no standalone ACTIVATE cycle needed. Tap 1 folds in the r_acc
    reset via acc.add.first (replacing the BN twin's separate bias-seed cycle);
    the NEXT channel's kr=-1 prefetch load also fuses into tap 9's word
    (XMEM reads lr5 live, post-LR-phase, so the same-cycle slot rotation is
    visible to the load). Net: 11 -> 9 cyc/ch.

    KERNEL PACKING (FPB=28, 9-byte stride, no bias byte): each channel s in a
    256-byte super-block occupies bytes [s*9 .. s*9+9) = its 9 weight taps.
    28*9 = 252 <= 256. The kernel byte index lr6 walks +1 every cycle across
    taps 1..9 (9 total = one channel stride).

    CR registers (set by harness; row-addressed ISA
    (issue #179): XMEM offset/base operands are ROW numbers, r_cyclic index/rc_idx
    operands are still ELEMENT numbers -- see cr1 vs cr12/cr13/cr9 below):
      cr0  = read-only 0 (zero constant)
      cr1  = read-only 1 (XMEM row stride: "one chunk" == one row)
      cr2  = output base row - 1 (deferred-store pre-bias, ROW-space)
      cr3  = mask blob base row (single blob, slots 0/3/6; loaded once at init)
      cr4  = cols
      cr5  = kernel base row
      cr6  = group_stride IN ROWS (= channels; one row per channel)
      cr7  = FPB (= 28; channel-group inner-loop size, in rows)
      cr8  = total_kernel_rows (= num_super_blocks * 2)
      cr9  = 384 (r_cyclic ELEMENT slot-pointer step, +384 mod 512, for lr5)
      cr10 = input base row (guard-band-shifted; also the cyclic-load base)
      cr11 = chunk-loop limit, ROWS (= (num_chunks - 1)*group_stride + group_stride,
             guard-band biased so g0's kr=-1 prefetch never goes negative)
      cr12 = 128 (r_cyclic ELEMENT slot size -- NOT an XMEM stride)
      cr13 = 256 (r_cyclic ELEMENT half-slot step)
      cr14 = 256 - 2*cols - 2  (r_cyclic ELEMENT end-of-9 walking step, unchanged)

    Mask scheme (mask shift for L/R, single 3-slot blob for vertical borders):
      Left/right edge columns are zeroed by mask_shift (NOT by slots), with
      CR15.partition = cols so each partition group is one packed spatial row:
        kc=-1 -> mask_shift = lr9  (+1): zeros START col of each row.
        kc= 0 -> mask_shift = lr0  ( 0): no shift.
        kc=+1 -> mask_shift = lr13 (-1): zeros END col of each row.
      Vertical off-image rows use mask slots from a SINGLE blob (loaded once at
      init from cr3); no mid-program R_MASK reload, no zero region:
        slot 0 = all-pass (KEEP) -> interior / kr=0 row taps.
        slot 3 = top-row zero     -> g0 taps 1-3 (kr=-1, row 0 out of bounds).
        slot 6 = bottom-row zero  -> gN taps 7-9 (kr=+1, last row out of bounds).
      The kc shift adds the edge column on top of the row zero.

    LR allocation:
    Slot pointers: lr4 = read pointer (computation; rotated +256 mod 512 at tap 8).
      lr5 = the SOLE running write/load-slot pointer, advanced only by
      inc.modp2 (mod 512) so it never overflows the 512-byte cyclic register;
      per channel it steps +384, +128, +256 (taps 4, 5, 9) — net +256 = lr4's
      rotation.  lr5 is self-contained: it is NOT recomputed from lr4.

      lr0=0  lr1=cols-2  lr2=this-ch kr=0 ext  lr3=walk  lr4=read  lr5=write slot
      lr6=kernel byte idx  lr7=output ptr  lr8=chunk base  lr9=+1 (kc=-1 shift)
      lr10=ch byte counter  lr11=clamp limit  lr12=kernel super-block offset
      lr13=-1 (kc=+1 shift)  lr14=scratch

    ===========================================================================
    Initialization
    ===========================================================================
-#}
{#- The variants (../registry.toml): seeded = the bias-seed program; the activation follows apply_relu. -#}
{%- set seeded = has_bias or apply_relu -%}
{%- set activation = "relu" if apply_relu else "identity" -%}
    SET                 LR0 CR0;
    LD.MASK   LR0 {{ cr.border_mask }};;
    ADD                 LR1 LR0 {{ cr.cols }};
    ADD                 LR8 LR0 {{ cr.in_channels }};
    SET                 LR7 CR0;;
    SUB                 LR7 LR7 CR1;;
    DEC                 LR1 2;
    ADD                 LR9 LR0 CR1;
    SUB                 LR13 LR0 CR1;;
    SET                 LR12 CR0;;
g0_kg_loop:
    LD.MULT        R0 LR12 {{ cr.filters }};
    SET                 LR6 CR0;;
    ADD                 LR14 LR12 CR1;
    SET                 LR10 CR0;
    LD.MULT        R1 LR14 {{ cr.filters }};;
    ADD                 LR11 LR10 {{ cr.fpb }};;
    BLT.S                 {{ cr.in_channels }} LR11 g0_clamp;;
    B                   g0_ch_pre;;
g0_clamp:
    ADD                 LR11 LR0 {{ cr.in_channels }};;
g0_ch_pre:
    SET                 LR4 CR0;
    SET                 LR5 CR0;
    ADD                 LR2 LR8 LR10;
    LD.MULT.CYCLIC LR2 {{ cr.x }} LR5;;
    ADD                 LR5 LR5 {{ cr.slot_stride }};
    ADD                 LR14 LR2 {{ cr.in_channels }};
    SET                 LR3 CR1;
    LD.MULT.CYCLIC LR14 {{ cr.x }} LR5;;
    SUB                 LR3 LR3 {{ cr.half_slot }};
    ADD                 LR5 LR5 {{ cr.half_slot }};;
    ADD                 LR3 LR3 {{ cr.cols }};
    SUB                 LR6 LR0 CR1;;
    B                   g0_tap_body;;
g0_tap_body:
{%- if seeded %}
    INC                 LR6 1;
    LD.MULT.CYCLIC LR2 {{ cr.x }} LR5;
    MULT.EE             LR6 CR1 0 LR0 CR15 ;
    ACC.ADD.FIRST;;
{%- endif %}
    ADD                 LR3 LR3 {{ cr.walk_step }};
    INC                 LR6 1;
{%- if not seeded %}
    ADD                 LR10 LR10 CR1;
{%- endif %}
    MULT.RC.VE          LR3 LR6 3 LR9 CR15 ;
{%- if seeded %}
    ACC.ADD;;
{%- else %}
    ACC.ADD.FIRST;;
{%- endif %}
    INC                 LR3 1;
    INC                 LR6 1;
    ADD                 LR7 LR7 CR1;
    ST.AAQ    LR7 {{ cr.y }};
    MULT.RC.VE          LR3 LR6 3 LR0 CR15 ;
    ACC.ADD;;
    INC                 LR3 1;
    INC                 LR6 1;
    ADD                 LR2 LR2 CR1;
    MULT.RC.VE          LR3 LR6 3 LR13 CR15 ;
    ACC.ADD;;
    ADD                 LR3 LR3 LR1;
    INC                 LR6 1;
    INC.MODP2       LR5 {{ cr.ring_adv }} 9;
    LD.MULT.CYCLIC LR2 {{ cr.x }} LR5;
    MULT.RC.VE          LR3 LR6 0 LR9 CR15 ;
    ACC.ADD;;
    INC                 LR3 1;
    INC                 LR6 1;
    INC.MODP2       LR5 {{ cr.slot_stride }} 9;
    MULT.RC.VE          LR3 LR6 0 LR0 CR15 ;
    ACC.ADD;;
    INC                 LR3 1;
    INC                 LR6 1;
{%- if seeded %}
    ADD                 LR10 LR10 CR1;
{%- else %}
    INC.MODP2       LR4 {{ cr.half_slot }} 9;
{%- endif %}
    MULT.RC.VE          LR3 LR6 0 LR13 CR15 ;
    ACC.ADD;;
    ADD                 LR3 LR3 LR1;
    INC                 LR6 1;
    ADD                 LR14 LR2 {{ cr.in_channels }};
    LD.MULT.CYCLIC LR14 {{ cr.x }} LR5;
    MULT.RC.VE          LR3 LR6 0 LR9 CR15 ;
    ACC.ADD;;
    INC                 LR3 1;
    INC                 LR6 1;
{%- if seeded %}
    INC.MODP2       LR4 {{ cr.half_slot }} 9;
{%- else %}
    SUB                 LR14 LR2 {{ cr.in_channels }};
{%- endif %}
    MULT.RC.VE          LR3 LR6 0 LR0 CR15 ;
    ACC.ADD;;
    INC                 LR3 1;
    INC                 LR6 1;
    INC.MODP2       LR5 {{ cr.half_slot }} 9;
{%- if not seeded %}
    LD.MULT.CYCLIC LR14 {{ cr.x }} LR5;
{%- endif %}
    MULT.RC.VE          LR3 LR6 0 LR13 CR15 ;
    ACC.ADD;
    ACTIVATE.QUANTIZE {{ activation }} CR15;
    BLT.S                 LR10 LR11 g0_tap_body;;
    ADD                 LR12 LR12 CR1;;
    ADD                 LR12 LR12 CR1;
    BLT.S                 LR10 {{ cr.in_channels }} g0_reload;;
    B                   main_setup;;
g0_reload:
    LD.MULT        R0 LR12 {{ cr.filters }};
    SET                 LR6 CR0;;
    ADD                 LR14 LR12 CR1;
    LD.MULT        R1 LR14 {{ cr.filters }};;
    ADD                 LR11 LR10 {{ cr.fpb }};;
    BLT.S                 {{ cr.in_channels }} LR11 g0_reload_clamp;;
    B                   g0_ch_pre;;
g0_reload_clamp:
    ADD                 LR11 LR0 {{ cr.in_channels }};
    B                   g0_ch_pre;;
main_setup:
    ADD                 LR8 LR8 {{ cr.in_channels }};;
    BLT.S                 LR8 {{ cr.chunk_limit }} row_loop;;
    B                   gN_section;;
row_loop:
    SET                 LR12 CR0;;
kg_loop:
    LD.MULT        R0 LR12 {{ cr.filters }};
    SET                 LR6 CR0;;
    ADD                 LR14 LR12 CR1;
    SET                 LR10 CR0;
    LD.MULT        R1 LR14 {{ cr.filters }};;
    ADD                 LR11 LR10 {{ cr.fpb }};;
    BLT.S                 {{ cr.in_channels }} LR11 mn_clamp;;
    B                   ch_pre;;
mn_clamp:
    ADD                 LR11 LR0 {{ cr.in_channels }};;
ch_pre:
    SET                 LR4 CR0;
    SET                 LR5 CR0;
    ADD                 LR2 LR8 LR10;
    LD.MULT.CYCLIC LR2 {{ cr.x }} LR5;;
    ADD                 LR5 LR5 {{ cr.slot_stride }};
    ADD                 LR14 LR2 {{ cr.in_channels }};
    SET                 LR3 CR1;
    LD.MULT.CYCLIC LR14 {{ cr.x }} LR5;;
    SUB                 LR3 LR3 {{ cr.half_slot }};
    ADD                 LR5 LR5 {{ cr.half_slot }};;
    ADD                 LR3 LR3 {{ cr.cols }};
{%- if seeded %}
    SUB                 LR6 LR0 CR1;;
{%- else %}
    SUB                 LR6 LR0 CR1;
    SUB                 LR14 LR2 {{ cr.in_channels }};
    LD.MULT.CYCLIC LR14 {{ cr.x }} LR5;;
{%- endif %}
    B                   mn_tap_body;;
mn_tap_body:
{%- if seeded %}
    INC                 LR6 1;
    SUB                 LR14 LR2 {{ cr.in_channels }};
    LD.MULT.CYCLIC LR14 {{ cr.x }} LR5;
    MULT.EE             LR6 CR1 0 LR0 CR15 ;
    ACC.ADD.FIRST;;
{%- endif %}
    ADD                 LR3 LR3 {{ cr.walk_step }};
    INC                 LR6 1;
{%- if not seeded %}
    ADD                 LR10 LR10 CR1;
{%- endif %}
    MULT.RC.VE          LR3 LR6 0 LR9 CR15 ;
{%- if seeded %}
    ACC.ADD;;
{%- else %}
    ACC.ADD.FIRST;;
{%- endif %}
    INC                 LR3 1;
    INC                 LR6 1;
    ADD                 LR7 LR7 CR1;
    ST.AAQ    LR7 {{ cr.y }};
    MULT.RC.VE          LR3 LR6 0 LR0 CR15 ;
    ACC.ADD;;
    INC                 LR3 1;
    INC                 LR6 1;
    ADD                 LR2 LR2 CR1;
    MULT.RC.VE          LR3 LR6 0 LR13 CR15 ;
    ACC.ADD;;
    ADD                 LR3 LR3 LR1;
    INC                 LR6 1;
    INC.MODP2       LR5 {{ cr.ring_adv }} 9;
    LD.MULT.CYCLIC LR2 {{ cr.x }} LR5;
    MULT.RC.VE          LR3 LR6 0 LR9 CR15 ;
    ACC.ADD;;
    INC                 LR3 1;
    INC                 LR6 1;
    INC.MODP2       LR5 {{ cr.slot_stride }} 9;
    MULT.RC.VE          LR3 LR6 0 LR0 CR15 ;
    ACC.ADD;;
    INC                 LR3 1;
    INC                 LR6 1;
{%- if seeded %}
    ADD                 LR10 LR10 CR1;
{%- else %}
    INC.MODP2       LR4 {{ cr.half_slot }} 9;
{%- endif %}
    MULT.RC.VE          LR3 LR6 0 LR13 CR15 ;
    ACC.ADD;;
    ADD                 LR3 LR3 LR1;
    INC                 LR6 1;
    ADD                 LR14 LR2 {{ cr.in_channels }};
    LD.MULT.CYCLIC LR14 {{ cr.x }} LR5;
    MULT.RC.VE          LR3 LR6 0 LR9 CR15 ;
    ACC.ADD;;
    INC                 LR3 1;
    INC                 LR6 1;
{%- if seeded %}
    INC.MODP2       LR4 {{ cr.half_slot }} 9;
{%- else %}
    SUB                 LR14 LR2 {{ cr.in_channels }};
{%- endif %}
    MULT.RC.VE          LR3 LR6 0 LR0 CR15 ;
    ACC.ADD;;
    INC                 LR3 1;
    INC                 LR6 1;
    INC.MODP2       LR5 {{ cr.half_slot }} 9;
{%- if not seeded %}
    LD.MULT.CYCLIC LR14 {{ cr.x }} LR5;
{%- endif %}
    MULT.RC.VE          LR3 LR6 0 LR13 CR15 ;
    ACC.ADD;
    ACTIVATE.QUANTIZE {{ activation }} CR15;
    BLT.S                 LR10 LR11 mn_tap_body;;
    ADD                 LR12 LR12 CR1;;
    ADD                 LR12 LR12 CR1;
    BLT.S                 LR10 {{ cr.in_channels }} mn_reload;;
    ADD                 LR8 LR8 {{ cr.in_channels }};;
    BLT.S                 LR8 {{ cr.chunk_limit }} row_loop;;
    B                   gN_section;;
mn_reload:
    LD.MULT        R0 LR12 {{ cr.filters }};
    SET                 LR6 CR0;;
    ADD                 LR14 LR12 CR1;
    LD.MULT        R1 LR14 {{ cr.filters }};;
    ADD                 LR11 LR10 {{ cr.fpb }};;
    BLT.S                 {{ cr.in_channels }} LR11 mn_reload_clamp;;
    B                   ch_pre;;
mn_reload_clamp:
    ADD                 LR11 LR0 {{ cr.in_channels }};
    B                   ch_pre;;
gN_section:
    SET                 LR12 CR0;;
gN_kg_loop:
    LD.MULT        R0 LR12 {{ cr.filters }};
    SET                 LR6 CR0;;
    ADD                 LR14 LR12 CR1;
    SET                 LR10 CR0;
    LD.MULT        R1 LR14 {{ cr.filters }};;
    ADD                 LR11 LR10 {{ cr.fpb }};;
    BLT.S                 {{ cr.in_channels }} LR11 gN_clamp;;
    B                   gN_ch_pre;;
gN_clamp:
    ADD                 LR11 LR0 {{ cr.in_channels }};;
gN_ch_pre:
    SET                 LR4 CR0;
    SET                 LR5 CR0;
    ADD                 LR2 LR8 LR10;
    LD.MULT.CYCLIC LR2 {{ cr.x }} LR5;;
    ADD                 LR5 LR5 {{ cr.slot_stride }};
    SET                 LR3 CR1;
    LD.MULT.CYCLIC LR2 {{ cr.x }} LR5;;
    SUB                 LR3 LR3 {{ cr.half_slot }};
    ADD                 LR5 LR5 {{ cr.half_slot }};;
    ADD                 LR3 LR3 {{ cr.cols }};
{%- if seeded %}
    SUB                 LR6 LR0 CR1;;
{%- else %}
    SUB                 LR6 LR0 CR1;
    SUB                 LR14 LR2 {{ cr.in_channels }};
    LD.MULT.CYCLIC LR14 {{ cr.x }} LR5;;
{%- endif %}
    B                   gN_tap_body;;
gN_tap_body:
{%- if seeded %}
    INC                 LR6 1;
    SUB                 LR14 LR2 {{ cr.in_channels }};
    LD.MULT.CYCLIC LR14 {{ cr.x }} LR5;
    MULT.EE             LR6 CR1 0 LR0 CR15 ;
    ACC.ADD.FIRST;;
{%- endif %}
    ADD                 LR3 LR3 {{ cr.walk_step }};
    INC                 LR6 1;
{%- if not seeded %}
    ADD                 LR10 LR10 CR1;
{%- endif %}
    MULT.RC.VE          LR3 LR6 0 LR9 CR15 ;
{%- if seeded %}
    ACC.ADD;;
{%- else %}
    ACC.ADD.FIRST;;
{%- endif %}
    INC                 LR3 1;
    INC                 LR6 1;
    ADD                 LR7 LR7 CR1;
    ST.AAQ    LR7 {{ cr.y }};
    MULT.RC.VE          LR3 LR6 0 LR0 CR15 ;
    ACC.ADD;;
    INC                 LR3 1;
    INC                 LR6 1;
    ADD                 LR2 LR2 CR1;
    MULT.RC.VE          LR3 LR6 0 LR13 CR15 ;
    ACC.ADD;;
    ADD                 LR3 LR3 LR1;
    INC                 LR6 1;
    INC.MODP2       LR5 {{ cr.ring_adv }} 9;
    LD.MULT.CYCLIC LR2 {{ cr.x }} LR5;
    MULT.RC.VE          LR3 LR6 0 LR9 CR15 ;
    ACC.ADD;;
    INC                 LR3 1;
    INC                 LR6 1;
    INC.MODP2       LR5 {{ cr.slot_stride }} 9;
    MULT.RC.VE          LR3 LR6 0 LR0 CR15 ;
    ACC.ADD;;
    INC                 LR3 1;
    INC                 LR6 1;
{%- if seeded %}
    ADD                 LR10 LR10 CR1;
{%- endif %}
    LD.MULT.CYCLIC LR2 {{ cr.x }} LR5;
    MULT.RC.VE          LR3 LR6 0 LR13 CR15 ;
    ACC.ADD;;
    ADD                 LR3 LR3 LR1;
    INC                 LR6 1;
{%- if not seeded %}
    SUB                 LR14 LR2 {{ cr.in_channels }};
{%- endif %}
    MULT.RC.VE          LR3 LR6 6 LR9 CR15 ;
    ACC.ADD;;
    INC                 LR3 1;
    INC                 LR6 1;
    INC.MODP2       LR4 {{ cr.half_slot }} 9;
    MULT.RC.VE          LR3 LR6 6 LR0 CR15 ;
    ACC.ADD;;
    INC                 LR3 1;
    INC                 LR6 1;
    INC.MODP2       LR5 {{ cr.half_slot }} 9;
{%- if not seeded %}
    LD.MULT.CYCLIC LR14 {{ cr.x }} LR5;
{%- endif %}
    MULT.RC.VE          LR3 LR6 6 LR13 CR15 ;
    ACC.ADD;
    ACTIVATE.QUANTIZE {{ activation }} CR15;
    BLT.S                 LR10 LR11 gN_tap_body;;
    ADD                 LR12 LR12 CR1;;
    ADD                 LR12 LR12 CR1;
    BLT.S                 LR10 {{ cr.in_channels }} gN_reload;;
end:
    ADD                 LR7 LR7 CR1;
    ST.AAQ    LR7 {{ cr.y }};;
    HALT;;
gN_reload:
    LD.MULT        R0 LR12 {{ cr.filters }};
    SET                 LR6 CR0;;
    ADD                 LR14 LR12 CR1;
    LD.MULT        R1 LR14 {{ cr.filters }};;
    ADD                 LR11 LR10 {{ cr.fpb }};;
    BLT.S                 {{ cr.in_channels }} LR11 gN_reload_clamp;;
    B                   gN_ch_pre;;
gN_reload_clamp:
    ADD                 LR11 LR0 {{ cr.in_channels }};
    B                   gN_ch_pre;;
