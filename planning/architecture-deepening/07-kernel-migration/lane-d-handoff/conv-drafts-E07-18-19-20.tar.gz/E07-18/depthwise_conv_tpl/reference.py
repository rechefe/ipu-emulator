"""depthwise_conv_tpl's golden: ``filters`` holds each channel's bias, then its 9
taps (one region, as the program reads them), so split it and take the family's
shared conv2d with groups = channels. The bias is added only when the program
reads it: when seeded (has_bias or apply_relu), as the .asm and the pack decide."""

from ipu_kernels.reference.ops import conv2d


def reference(x, filters, **params):
    """``act(depthwise conv2d(x, w, padding 1) + b)``, w and b from ``filters``."""
    w = filters[:, 1:].reshape(filters.shape[0], 1, 3, 3)
    seeded = params["has_bias"] or params["apply_relu"]
    return conv2d(x, w, filters[:, 0] if seeded else None, **params)
