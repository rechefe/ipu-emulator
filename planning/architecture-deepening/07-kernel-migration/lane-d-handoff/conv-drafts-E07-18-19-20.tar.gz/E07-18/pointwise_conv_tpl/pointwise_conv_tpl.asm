{#- pointwise_conv_tpl.asm -- y = act(conv2d(x, w, 1x1) [+ b]), FP32 wide vectors, any in_channels via a multi-pass inner loop.

    Unified Pointwise (1x1) Convolution

    A single code path handling any valid pointwise convolution via a multi-pass
    inner loop. Kernel layout: one OC per 128-byte register (zero-padded).

    See DESIGN.md (sibling file) for the structural overview.

    Row-addressed ISA (issue #179): XMEM offset/base operands on LD.MULT /
    LD.MULT.CYCLIC's offset+base / LD.MASK / ST.AAQ are
    ROW numbers, not byte addresses. LD.MULT.CYCLIC's `index` (3rd operand,
    selecting the R_CYCLIC write slot) and MULT.RC.VE's `rc_idx` operand stay
    ELEMENT-indexed (0/128/256/384) -- the ring is 512 elements in both modes
    and is unaffected by row addressing. This app has NO spatial taps (1x1
    conv), so unlike the 3x3 conv/depthwise apps there is no kr=-1 prefetch and
    no negative-offset guard band needed -- lr0 starts at row 0 and only ever
    increases.

    cr12 (=128) is NOT used for XMEM strides. The r_cyclic-adjacent walking
    step is handled by lr6/lr8/lr9's ELEMENT-space roles, and the XMEM-space
    strides (output stride, kernel-row advance, output pre-offset) use CR1
    (read-only 1: one XMEM chunk == one row); cr12's only role is the fixed_idx
    step (128 lanes) for Half B, which is lane/element space and mode-blind.

    lr6/lr8/lr9 are also overloaded: as the 3rd (index) operand to
    LD.MULT.CYCLIC and the rc_idx operand to MULT.RC.VE they are ELEMENT
    values (128/256/384). They are NOT added into lr0/lr13/lr14 to form the
    NEXT XMEM read address -- in row addressing 128 elements == 1 row, not 128
    rows. The one-shot "+2 rows" / "+3 rows" computations are built from
    two/three chained `add ... cr1` words instead (ADD's src_a
    reads snapshot, so a same-word double-add into the same destination isn't
    possible -- see the row-addressing recipe's depthwise cr13 precedent). The
    walking-pointer step inside each PIPELINE_BODY (`lr14 += lr6`, one row per
    iteration) is `lr14 += cr1` directly.

    CR register parameters (CR0 = read-only 0, CR1 = read-only 1):
      cr0  = 0 constant AND input/cyclic-load base (INPUT_BASE_ROW == 0)
      cr1  = 1 (row stride: pass-counter decrement AND the XMEM row-space unit)
      cr2  = mask base row           (128 bytes of 0xFF — keep-all, new polarity;
             mask data itself does NOT widen, only its row address scales)
      cr3  = output base row
      cr4  = num_passes              (= ceil(in_ch / 128))
      cr5  = row_groups              (= rows * cols / 128)
      cr6  = pipeline_limit_full     (= 128 - 5 = 123)
      cr7  = out_channels
      cr8  = row_group_stride, in ROWS (= in_ch; one row per input channel)
      cr9  = pipeline_limit_tail     (= tail_size - 5; may be neg as 2's comp)
      cr10 = tail_size               (1..128)
      cr11 = num_passes - 1
      cr12 = 128 (fixed_idx step for Half B -- lane/element space, NOT an XMEM
             stride; that role is CR1)
      cr13 = 128 ROWS (input pass stride = 128 ICs * 1 row/IC)
      cr14 = kernel base row          (CR1 is read-only)

    LR register allocation:
      lr0  = input row-group base row (constant per row-group)
      lr1  = output pointer row (pre-offset by -1)
      lr2  = row-group counter
      lr3  = output channel counter
      lr4  = fixed_idx within the current register (0..127 for A, 128..255 for B)
      lr5  = 1 (output row stride)
      lr6  = 128 (r_cyclic ELEMENT index -- S1 slot / rc_idx; NOT an XMEM delta)
      lr7  = 0   (cyclic S0 offset)
      lr8  = 256 (cyclic S2 offset)
      lr9  = 384 (cyclic S3 offset)
      lr10 = pass_counter  (counts down; 0 means we are in the LAST pass)
      lr11 = row_groups
      lr12 = kernel row offset (advances by 1 row per pass within an OC)
      lr13 = input base row for the NEXT pass's preload (= lr0 for last-pass
             epilogue, or lr0 + (p+1)*128 rows for non-last-pass epilogue)
      lr14 = temp (address computation; base for cyclic streaming loads, in ROWS)
      lr15 = per-pass pipeline bound (lr4 + pipeline_limit)

    ===========================================================================
    Initialization
    ===========================================================================
-#}
{#- The variants (../registry.toml): seeded = the bias-seed program; the activation follows apply_relu. -#}
{%- set seeded = apply_relu -%}
{%- set activation = "relu" if apply_relu else "identity" -%}
    SET                 LR7 CR0;
    LD.MASK   LR7 {{ cr.mask }};
{%- if seeded %}
    ADD                 LR5 LR7 {{ cr.fixed_idx_step }};;
{%- else %}
    ADD                 LR5 LR7 CR1;;
{%- endif %}
    ADD                 LR6 LR7 {{ cr.fixed_idx_step }};;
    ADD                 LR8 LR6 LR6;;
    ADD                 LR9 LR6 LR8;;
    ADD                 LR11 LR7 {{ cr.row_groups }};;
    SET                 LR1 CR0;;
    SUB                 LR1 LR1 CR1;;
    SET                 LR2 CR0;;
row_loop:
    LD.MULT.CYCLIC LR0 CR0 LR7;;
    ADD                 LR14 LR0 CR1;
    LD.MULT.CYCLIC LR14 CR0 LR6;;
    ADD                 LR14 LR14 CR1;;
    LD.MULT.CYCLIC LR14 CR0 LR8;;
    ADD                 LR14 LR14 CR1;;
    LD.MULT.CYCLIC LR14 CR0 LR9;;
    SET                 LR3 CR0;
    SET                 LR12 CR0;;
oc_pair_loop:
{%- if seeded %}
    LD.MULT        R0 LR12 {{ cr.b }};;
    MULT.EE             LR7 CR1 0 LR7 CR15 ;
    ACC.ADD.FIRST;;
{%- endif %}
    LD.MULT        R0 LR12 {{ cr.w }};;
    SET                 LR4 CR0;
    ADD                 LR10 LR7 {{ cr.last_pass }};
    ADD                 LR13 LR0 LR7;;
    BLT.S                 LR7 LR10 W1_FULL_A;;
    ADD                 LR14 LR0 CR1;
    ADD                 LR15 LR4 {{ cr.pipeline_limit_tail }};;
    ADD                 LR14 LR14 CR1;;
    ADD                 LR14 LR14 CR1;
    MULT.RC.VE          LR7 LR4 0 LR7 CR15 ;
{%- if seeded %}
    ACC.ADD;;
{%- else %}
    ACC.ADD.FIRST;;
{%- endif %}
    BLT.S                 LR4 LR15 PIPELINE_BODY_A;;
    B                   POST_BODY_A;;
W1_FULL_A:
    ADD                 LR14 LR0 CR1;
    ADD                 LR15 LR4 {{ cr.pipeline_limit_full }};;
    ADD                 LR14 LR14 CR1;;
    ADD                 LR14 LR14 CR1;
    MULT.RC.VE          LR7 LR4 0 LR7 CR15 ;
{%- if seeded %}
    ACC.ADD;;
{%- else %}
    ACC.ADD.FIRST;;
{%- endif %}
PIPELINE_BODY_A:
    INC                 LR4 1;
    ADD                 LR14 LR14 CR1;
    LD.MULT.CYCLIC LR14 CR0 LR7;
    MULT.RC.VE          LR6 LR4 0 LR7 CR15 ;
    ACC.ADD;;
    INC                 LR4 1;
    ADD                 LR14 LR14 CR1;
    LD.MULT.CYCLIC LR14 CR0 LR6;
    MULT.RC.VE          LR8 LR4 0 LR7 CR15 ;
    ACC.ADD;;
    INC                 LR4 1;
    ADD                 LR14 LR14 CR1;
    LD.MULT.CYCLIC LR14 CR0 LR8;
    MULT.RC.VE          LR9 LR4 0 LR7 CR15 ;
    ACC.ADD;;
    INC                 LR4 1;
    ADD                 LR14 LR14 CR1;
    LD.MULT.CYCLIC LR14 CR0 LR9;
    MULT.RC.VE          LR7 LR4 0 LR7 CR15 ;
    ACC.ADD;
    BLT.S                 LR4 LR15 PIPELINE_BODY_A;;
POST_BODY_A:
    BLT.S                 LR7 LR10 MID_EPILOGUE_A;;
LAST_EPILOGUE_A:
    INC                 LR4 1;
    LD.MULT.CYCLIC LR0 CR0 LR7;
    MULT.RC.VE          LR6 LR4 0 LR7 CR15 ;
    ACC.ADD;;
    INC                 LR4 1;
    ADD                 LR14 LR0 CR1;
    LD.MULT.CYCLIC LR14 CR0 LR6;
    MULT.RC.VE          LR8 LR4 0 LR7 CR15 ;
    ACC.ADD;;
    ADD                 LR14 LR14 CR1;;
    INC                 LR4 1;
    LD.MULT.CYCLIC LR14 CR0 LR8;
    MULT.RC.VE          LR9 LR4 0 LR7 CR15 ;
    ACC.ADD;;
    ADD                 LR14 LR14 CR1;;
    INC                 LR4 1;
{%- if seeded %}
    ADD                 LR1 LR1 CR1;
{%- else %}
    ADD                 LR1 LR1 LR5;
{%- endif %}
    LD.MULT.CYCLIC LR14 CR0 LR9;
    ACTIVATE.QUANTIZE {{ activation }} CR15;;
    INC                 LR3 1;
    ADD                 LR12 LR12 CR1;
    ST.AAQ    LR1 {{ cr.y }};;
    ADD                 LR14 LR7 {{ cr.out_channels }};;
    BLT.S                 LR3 LR14 HALF_B_GO;;
    B                   END_ROW_GROUP_CHECK;;
HALF_B_GO:
{%- if seeded %}
    LD.MULT        R1 LR12 {{ cr.b }};;
    MULT.EE             LR5 CR1 0 LR7 CR15 ;
    ACC.ADD.FIRST;;
{%- endif %}
    LD.MULT        R1 LR12 {{ cr.w }};;
    ADD                 LR4 LR7 {{ cr.fixed_idx_step }};
    ADD                 LR10 LR7 {{ cr.last_pass }};
    ADD                 LR13 LR0 LR7;;
    BLT.S                 LR7 LR10 W1_FULL_B;;
    ADD                 LR14 LR0 CR1;
    ADD                 LR15 LR4 {{ cr.pipeline_limit_tail }};;
    ADD                 LR14 LR14 CR1;;
    ADD                 LR14 LR14 CR1;
    MULT.RC.VE          LR7 LR4 0 LR7 CR15 ;
{%- if seeded %}
    ACC.ADD;;
{%- else %}
    ACC.ADD.FIRST;;
{%- endif %}
    BLT.S                 LR4 LR15 PIPELINE_BODY_B;;
    B                   POST_BODY_B;;
W1_FULL_B:
    ADD                 LR14 LR0 CR1;
    ADD                 LR15 LR4 {{ cr.pipeline_limit_full }};;
    ADD                 LR14 LR14 CR1;;
    ADD                 LR14 LR14 CR1;
    MULT.RC.VE          LR7 LR4 0 LR7 CR15 ;
{%- if seeded %}
    ACC.ADD;;
{%- else %}
    ACC.ADD.FIRST;;
{%- endif %}
PIPELINE_BODY_B:
    INC                 LR4 1;
    ADD                 LR14 LR14 CR1;
    LD.MULT.CYCLIC LR14 CR0 LR7;
    MULT.RC.VE          LR6 LR4 0 LR7 CR15 ;
    ACC.ADD;;
    INC                 LR4 1;
    ADD                 LR14 LR14 CR1;
    LD.MULT.CYCLIC LR14 CR0 LR6;
    MULT.RC.VE          LR8 LR4 0 LR7 CR15 ;
    ACC.ADD;;
    INC                 LR4 1;
    ADD                 LR14 LR14 CR1;
    LD.MULT.CYCLIC LR14 CR0 LR8;
    MULT.RC.VE          LR9 LR4 0 LR7 CR15 ;
    ACC.ADD;;
    INC                 LR4 1;
    ADD                 LR14 LR14 CR1;
    LD.MULT.CYCLIC LR14 CR0 LR9;
    MULT.RC.VE          LR7 LR4 0 LR7 CR15 ;
    ACC.ADD;
    BLT.S                 LR4 LR15 PIPELINE_BODY_B;;
POST_BODY_B:
    BLT.S                 LR7 LR10 MID_EPILOGUE_B;;
LAST_EPILOGUE_B:
    INC                 LR4 1;
    LD.MULT.CYCLIC LR0 CR0 LR7;
    MULT.RC.VE          LR6 LR4 0 LR7 CR15 ;
    ACC.ADD;;
    INC                 LR4 1;
    ADD                 LR14 LR0 CR1;
    LD.MULT.CYCLIC LR14 CR0 LR6;
    MULT.RC.VE          LR8 LR4 0 LR7 CR15 ;
    ACC.ADD;;
    ADD                 LR14 LR14 CR1;;
    INC                 LR4 1;
    LD.MULT.CYCLIC LR14 CR0 LR8;
    MULT.RC.VE          LR9 LR4 0 LR7 CR15 ;
    ACC.ADD;;
    ADD                 LR14 LR14 CR1;;
    INC                 LR4 1;
{%- if seeded %}
    ADD                 LR1 LR1 CR1;
{%- else %}
    ADD                 LR1 LR1 LR5;
{%- endif %}
    LD.MULT.CYCLIC LR14 CR0 LR9;
    ACTIVATE.QUANTIZE {{ activation }} CR15;;
    INC                 LR3 1;
    ADD                 LR12 LR12 CR1;
    ST.AAQ    LR1 {{ cr.y }};;
END_ROW_GROUP_CHECK:
    ADD                 LR14 LR7 {{ cr.out_channels }};;
    BLT.S                 LR3 LR14 oc_pair_loop;;
    ADD                 LR0 LR0 {{ cr.in_channels }};
    INC                 LR2 1;;
    BLT.S                 LR2 LR11 row_loop;;
end:
    HALT;;
MID_EPILOGUE_A:
    ADD                 LR13 LR13 {{ cr.pass_stride }};;
    INC                 LR4 1;
    LD.MULT.CYCLIC LR13 CR0 LR7;
    MULT.RC.VE          LR6 LR4 0 LR7 CR15 ;
    ACC.ADD;;
    INC                 LR4 1;
    ADD                 LR14 LR13 CR1;
    LD.MULT.CYCLIC LR14 CR0 LR6;
    MULT.RC.VE          LR8 LR4 0 LR7 CR15 ;
    ACC.ADD;;
    ADD                 LR14 LR14 CR1;;
    INC                 LR4 1;
    LD.MULT.CYCLIC LR14 CR0 LR8;
    MULT.RC.VE          LR9 LR4 0 LR7 CR15 ;
    ACC.ADD;;
    ADD                 LR14 LR14 CR1;;
    INC                 LR4 1;
    LD.MULT.CYCLIC LR14 CR0 LR9;;
    ADD                 LR12 LR12 CR1;
    SUB                 LR10 LR10 CR1;;
    LD.MULT        R0 LR12 {{ cr.w }};;
    SET                 LR4 CR0;;
    BLT.S                 LR7 LR10 MP_A_FULL;;
    ADD                 LR14 LR13 CR1;
    ADD                 LR15 LR4 {{ cr.pipeline_limit_tail }};;
    ADD                 LR14 LR14 CR1;;
    ADD                 LR14 LR14 CR1;
    MULT.RC.VE          LR7 LR4 0 LR7 CR15 ;
    ACC.ADD;;
    BLT.S                 LR4 LR15 PIPELINE_BODY_A;;
    B                   POST_BODY_A;;
MP_A_FULL:
    ADD                 LR14 LR13 CR1;
    ADD                 LR15 LR4 {{ cr.pipeline_limit_full }};;
    ADD                 LR14 LR14 CR1;;
    ADD                 LR14 LR14 CR1;
    MULT.RC.VE          LR7 LR4 0 LR7 CR15 ;
    ACC.ADD;;
    B                   PIPELINE_BODY_A;;
MID_EPILOGUE_B:
    ADD                 LR13 LR13 {{ cr.pass_stride }};;
    INC                 LR4 1;
    LD.MULT.CYCLIC LR13 CR0 LR7;
    MULT.RC.VE          LR6 LR4 0 LR7 CR15 ;
    ACC.ADD;;
    INC                 LR4 1;
    ADD                 LR14 LR13 CR1;
    LD.MULT.CYCLIC LR14 CR0 LR6;
    MULT.RC.VE          LR8 LR4 0 LR7 CR15 ;
    ACC.ADD;;
    ADD                 LR14 LR14 CR1;;
    INC                 LR4 1;
    LD.MULT.CYCLIC LR14 CR0 LR8;
    MULT.RC.VE          LR9 LR4 0 LR7 CR15 ;
    ACC.ADD;;
    ADD                 LR14 LR14 CR1;;
    INC                 LR4 1;
    LD.MULT.CYCLIC LR14 CR0 LR9;;
    ADD                 LR12 LR12 CR1;
    SUB                 LR10 LR10 CR1;;
    LD.MULT        R1 LR12 {{ cr.w }};;
    ADD                 LR4 LR7 {{ cr.fixed_idx_step }};;
    BLT.S                 LR7 LR10 MP_B_FULL;;
    ADD                 LR14 LR13 CR1;
    ADD                 LR15 LR4 {{ cr.pipeline_limit_tail }};;
    ADD                 LR14 LR14 CR1;;
    ADD                 LR14 LR14 CR1;
    MULT.RC.VE          LR7 LR4 0 LR7 CR15 ;
    ACC.ADD;;
    BLT.S                 LR4 LR15 PIPELINE_BODY_B;;
    B                   POST_BODY_B;;
MP_B_FULL:
    ADD                 LR14 LR13 CR1;
    ADD                 LR15 LR4 {{ cr.pipeline_limit_full }};;
    ADD                 LR14 LR14 CR1;;
    ADD                 LR14 LR14 CR1;
    MULT.RC.VE          LR7 LR4 0 LR7 CR15 ;
    ACC.ADD;;
    B                   PIPELINE_BODY_B;;
