"""pointwise_conv_tpl's golden: the family's shared conv2d of x and w [out, in, 1, 1].
The bias is added only when ``has_bias``: the seeded program without one (ReLU,
no bias) reads the zeros pass0_bias writes, whatever b the case generated."""

from ipu_kernels.reference.ops import conv2d


def reference(x, w, b=None, **params):
    """``act(conv2d(x, w) + b)``, b only when has_bias."""
    return conv2d(x, w, b if params["has_bias"] else None, **params)
