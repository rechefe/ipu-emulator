# E07-19 prep: `conv_universal_wide384` and `depthwise_conv_stride2_*` on params and stages

Draft only; nothing in the repo is edited. **Rebased on HEAD 9df1033f**
(E07-17 landed), on top of the E07-18 drafts (`../E07-18/`).

### Refresh at 9df1033f (lane D handoff)

- **H1 is fixed at HEAD.** `stages.py:219-222` now passes the kernel's
  `[abi]`, offsets included, when a stage gives no table. The monkeypatch is
  gone (`_check/stage_offsets_fix.py` is kept only as history), and the
  stride-2 `compare_legacy` rows pass unpatched.
- **wide384 `compare_setup` is plain `IDENTICAL`.** The LR0/LR2-LR5 presets
  are "bound reset values" now (7457754f).
- **The 7e0e0fd9 trap does not apply here.** The stride-2 kernels and wide384
  are fixed `has_bias = apply_relu = false`, so their programs are unseeded
  and `depthwise_filters` does not store column 0.
- **Latent bug #258** (the round-down) is cited below.
- **Re-run at 20:40 UTC:** wide384 has 4 cases and the stride-2 kernels 10,
  all `yes | yes` with equal (summed) cycles; routing 13/13. `W` =
`conv_universal_wide384/app.py`, `N` / `S128` / `S16` = the
`depthwise_conv_stride2_{narrow,128,16}/app.py` (under
`src/tools/ipu-apps/src/ipu_apps/kernels/convolutions/`).

## What changed since the first draft

- **`y_base` workaround dropped.** A stage table no longer picks up the
  `[abi]` offsets (0d575333), so stage 2 binds `y` at CR3 again.
- **Stage 1 takes no stage params.** The depthwise template reads
  `has_bias`/`apply_relu`, which the stride-2 kernels declare (fixed `false`).
- **Shared pieces reused:**
  - E07-16's packs `row_interleaved` (wide384 x and y) and
    `conv_weight_groups` (wide384 `w`, 14 input channels a row);
  - `chunked_guard` (stride-2 x);
  - family masks `../masks.py:border_mask` and `:wide_mask`.

  `fpb14_weights`, `rows_channel_interleaved` and the mask shims are gone;
  only `channel_pairs` is new.
- **wide384:** `[golden] op = "conv2d"` (tensors x, w, y). It presets LR0 and
  LR2-LR5 to 0: its init reads them on reset zeros (P1, E07-18 NOTES).
- **All parameters are `query_required`, without defaults.**
- **New harness finding, H1** (below): `compare_legacy`'s multi-stage path
  needed a one-line `stages.py` fix to pass.

## Result (`_check/run_check.out`)

| Kernel | Programs | `compare_setup` (poisoned) | `compare_legacy` (poisoned) |
|---|---|---|---|
| wide384 (4 cases) | E02 per (cpr, height): (3, 8) and (3, 16) are one binary; (4, 4) | 4/4 `IDENTICAL` (LR0, LR2-LR5 bound reset values) | 4/4 yes / yes, equal cycles |
| narrow (3), 128 (4), 16 (3) | stage 1 = `depthwise_conv_universal`'s E02 digest, stage 2 = its E02 digest (narrow per `elements_in_row` 32/64/16) | refuses stages kernels | **10/10 yes / yes, equal summed cycles** (HEAD, unpatched); the by-hand check (each stage's program = the old harness's, output bytes, cycles) agrees |

Routing (`_check/run_routing.out`) passes 13/13: the family `test_resolve`
stride-2/wide384 rows, widths 384/512/640, every old constructor refusal.
Re-run: `sh _check/mktree.sh`, `. ../env.sh`,
`PYTHONPATH=E07-19/_check:$PYTHONPATH`, then `$PY E07-19/_check/run_check.py`
and `run_routing.py` from the repo root.

## H1 (FIXED at HEAD, stages.py:219): a stage run with the kernel's `[abi]` lost its offsets

`stages.py:208-220` passes `bindings = self.manifest.abi` to
`register_writes(abi=bindings)` when the hook gives `abi=None`. Since
0d575333, `register_writes` drops the `[abi]` offsets for any explicit table.
So stage 1's CR2 is `base(y)`, not `base(y) - 1`, and every stride-2 output
is wrong (`compare_legacy` shows output NO).

The fix, one line in `stages.py`:
`register_writes(..., abi=None if abi is None else bindings, ...)`.

`_check/stage_offsets_fix.py` monkeypatches exactly that for the check.

## Files

| Draft | Becomes |
|---|---|
| `conv_universal_wide384/{kernel.toml, .asm, BUILD.bazel}` | `kernels/convolutions/conv_universal_wide384/` |
| `depthwise_conv_stride2_{narrow,128,16}/{kernel.toml, .asm, stages.py, reference.py, BUILD.bazel}` | `kernels/convolutions/<name>/`, BUILD `ipu_kernel(uses = ["depthwise_conv_tpl"])` |
| `convolutions/pack_additions.py` | `channel_pairs`, appended to the family `pack.py` |
| `../E07-18/convolutions/{masks,gen}_additions.py` | `wide_mask`; `legacy_depthwise` (seed), `legacy_wide` |
| `_check/build_stage2.py` | wrote the 4 `.asm` (drops the `{#- ipu:params` headers: no `| default` exists at HEAD) |

## wide384

`cpr` and `rows` cannot be `[params]` (the issue's plan): the query carries
`height`/`width`, and a `cpr` parameter would be one every query must name.
Templates see `[derived]`, so the program keeps its body behind
`{%- set CPR = cpr -%}` (`[derived] cpr = "width / 128"`) and
`{%- set ROWS = height -%}`. The CRs (W app.py:294-313):

| CR | Name | Value |
|---|---|---|
| CR2 | `x` | base |
| CR3 | `w` | base |
| CR4 | `y` | base |
| CR5 | `mask` | base |
| CR6 | `in_channels` | param |
| CR7 | `row_limit` | `(height - 1) * out * cpr` |
| CR8 | `fpb` | 14 |
| CR9 | `kernel_row_stride` | 1 |
| CR10 | `out_row_stride` | `out * cpr` |
| CR11 | `in_row_stride` | `in * cpr` |
| CR12 | `cpr` | `width / 128` |
| CR13 | `total_kernel_rows` | `out * ceil(in / 14)` |
| CR14 | `blocks_per_filter` | `ceil(in / 14)` |
| CR15 | (default) | |

LR0 and LR2-LR5 are presets of 0. Regions: x, w, mask, y (W :226-233).
`cost = 1` (W :380).

## Stride-2 (stages)

The three stage-2 programs differ in structure (22, 28 and 33 words), so
they stay three folder kernels. `stages.py`:

```python
def run(ctx):
    ctx.run_stage("../depthwise_conv_tpl/depthwise_conv_tpl.asm")   # [abi]: depthwise_conv_tpl's, unseeded
    ctx.run_stage("<name>.asm", abi={"y": "CR3", "in_channels": "CR4", "out": "CR5", "<count>": "CR6"})
```

- **Stage 2's CR15** is the default dstructure(128, P0), as `stage2_setup`
  wrote it (N :211-224); the PC reset comes from `load_program`. The other
  CRs and the LRs carry over from stage 1, as today.
- **`elements_in_row`** (narrow) is `[derived] elements_in_row = "width"`.
- **`<count>`** is `num_out_groups = "height * width / 512"`, which is whole
  exactly under today's narrow check (N :155-161), so it also serves as the
  refusal. For 128 it is `num_row_pairs = "height / 4"`; for 16,
  `num_channel_pairs = "in_channels / 2"`.
- **Regions** (today's order): x (headroom + chunks), filters `[C, 10]`,
  `border_mask`, the scratch `y` (stage 1's output, `num_chunks * C` rows),
  then `out` (N :192-196).
- **Output packs:** `chunk_interleaved` for narrow and 128, `channel_pairs`
  for 16.
- **Parked binding (approved):** stage 1 runs with the kernel's `[abi]`.
  Since every tensor must be bound and there is no per-stage `[abi]`, `out`
  is parked on CR8, which the depthwise program writes but never reads.
  Stage 1's CR8 is therefore base(out); outputs and cycles are unchanged.
- **`y` and `out`:** the scratch is named `y` because the shared program
  reads `{{ cr.y }}`. The final output is therefore `out`, and each kernel has
  a 6-line `reference.py`.
- **Stage-1 `[derived]` is duplicated:** 14 expressions copied from
  `depthwise_conv_tpl`. Proposed guard: a family test that compares the
  stage-1 register writes with the template's at the same shape.

## Cases

The `seed` parameter carries the legacy data and leaves with the
seeded-generator commit (`seed` is visible to routing until then).

| Kernel | Cases (legacy id -> new) |
|---|---|
| narrow | `default`; `channels=2,height=8,width=64,seed=3` -> `rpc2_c2`; `channels=3,height=32,width=16,seed=11` -> `rpc8_c3` |
| 128 | `default`; seeds 7/11/13 -> `c4_h16`, `c3_h32`, `c32_h128` |
| 16 | `default`; `c4`, `c320` |
| wide384 | `default` and 3 sweep points, ids matching |

The `--case-map` is `MAPS` in `_check/run_check.py`. Tolerance: FP32_ORDER for
all four, TO MEASURE. Benchmarks: `[benchmark]` from each CONFIGS
(`per = "in_channels"` for the stride-2 kernels, 50M).

## Tests from the old test files

### Tests from `conv_universal_wide384/test.py`

| Test | Now covered by |
|---|---|
| `test_case[default]`, `[in_channels=2,...,width=384]`, `[in_channels=3,...]`, `[in_channels=1,...,width=512]` | `bazel test //kernels/convolutions/conv_universal_wide384`, `test_case[default-fp32]`, `[sweep_2x2_h16[...]-fp32]`, `[sweep_3x4[...]-fp32]`, `[sweep_cpr4[...]-fp32]` |
| `test_odd_out_channels_rejected` | `kernels/convolutions/test_routing.py` refusal row (`out_channels = 3 is not a multiple of 2`). The constructor half is dropped: `plan_case` refuses by the same domain |

### Tests from `depthwise_conv_stride2_narrow/test.py`

| Test | Now covered by |
|---|---|
| `test_case[default]`, `[channels=2,...,seed=3]`, `[channels=3,...,seed=11]` | `test_case[default-fp32]`, `[rpc2_c2-fp32]`, `[rpc8_c3-fp32]` |
| `test_rejects_unsupported_shapes[5-64, 16-16, 8-128]` | `test_routing.py::test_stride2_refusals` (`num_out_groups` not whole; `width = 128 is not one of [16, 32, 64]`) |
| `test_stats_cover_both_stages` | `kernels/convolutions/test_stride2.py::test_stages_add_up` (`RunResult.stages` has 2 entries summing to `cycles`, `mac_utilization <= 1`) |

### Tests from `depthwise_conv_stride2_128/test.py`

| Test | Now covered by |
|---|---|
| `test_case[default]` + 3 sweep points | `test_case[default-fp32]`, `[c4_h16-fp32]`, `[c3_h32-fp32]`, `[c32_h128-fp32]` |
| `test_rejects_odd_rows` | `test_stride2_refusals` (`height = 5 is not a multiple of 4`) |
| `test_stats_cover_both_stages` | `test_stride2.py::test_stages_add_up` |

### Tests from `depthwise_conv_stride2_16/test.py`

| Test | Now covered by |
|---|---|
| `test_case[default]`, `[channels=4,seed=7]`, `[channels=320,seed=13]` | `test_case[default-fp32]`, `[c4-fp32]`, `[c320-fp32]` |
| `test_rejects_odd_channels` | `test_stride2_refusals` (`in_channels = 3 is not a multiple of 2`) |
| `test_stats_cover_both_stages` | `test_stride2.py::test_stages_add_up` |

New: `test_stride2.py::test_debug_stops_in_stage_2` (the issue's: a fake
`DebugHook` records the program it stops in).

### Tests moved out of `convolutions/test.py` (E07-19: its last tests)

| Test | Now covered by |
|---|---|
| `test_resolve[overrides4..6-depthwise_conv_stride2_{128,narrow,16}]`, `[overrides9-conv_universal_wide384]` | `test_routing.py::test_resolve` rows (verified) |
| `test_width_routing_boundaries` | `test_routing.py::test_width_routing_boundaries` (folds `Registry.resolve` over widths 1..640; the harness has no `boundaries`). It replaces E07-17's `test_width_129_is_refused` comment ("wide384 takes some wider images (E07-19)") |
| `test_output_shape_is_derived_for_stride2` | `test_routing.py`: `plan_case(...).shapes["out"] == (4, 4, 64)` (the new `Verdict` has no shapes) |
| the remaining `test_refusals` rows (stride 2 at width 128 for a plain conv) | `test_routing.py::test_universal_refusals` |

## Deletions that touch other files

`asm_corpus.py:71-84` (the wide384 and narrow define sets), `ruff.toml:76-77`
(the wide384 and pointwise `app.py` ignores), the `baseline.py:9` docstring,
the docs pages (`docs/content/kernels/convolutions.md`, `app-coverage.md`,
`building-applications.md`) and the disassembly snapshots of the 8 `.asm` files.

## Open questions (need a decision)

- **D1, the family `app.py` / `cases.py` / `test.py`.** The issue deletes
  `kernels/convolutions/app.py`. But `conv_universal/` is "kept until E07-26
  trace move" (DELETIONS.md:354), and its `app.py` imports the family
  `app.py` (`universal_spec`, `allocate_regions`, the packers); the old family
  `test.py`'s width table also needs wide384. Either keep the family
  `app.py`/`cases.py` (and the old wide384 folder?) until E07-26, logged as
  kept, or trim the family `app.py` to what `conv_universal` imports.
- **D2, H1: done at HEAD.**
- **D3, P1: done at HEAD** (bound reset values).
- **D4.** The scratch is named `y`, not the issue's `stage1_out` (no stage-name
  aliasing), and `out` is parked on CR8 (approved; per-stage `[abi]` deferred).
- **D5.** The duplicated stage-1 `[derived]` (above).

## Latent bugs

Stage 1 inherits B1 = **#258** (the depthwise template's `num_chunks` rounds
down while `chunked_guard` rounds up), but every stride-2 domain excludes the
inexact shapes. Not fixed here.
wide384 size-checks its inputs today (W :244-261, :273-277): no truncation.
