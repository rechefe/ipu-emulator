"""DRAFT (E07-19) checker: one stage-2 or wide384 program, from its old .asm.

Usage: build_stage2.py <old.asm> <out.asm> <crmap> <title>
Drops the old {#- ipu:params ... -#} header and its note (kernel.toml declares the
values; E05's strict render does not read a header), moves the leading '#'
comment block into a {#- ... -#} header, keeps every other comment and Jinja
line, maps raw CR numbers to {{ cr.<name> }} and upper-cases the mnemonics
(tools/upper_mnemonics.py). The wide384 extra: `set CPR = cpr` / `set ROWS = rows`
become derived reads (`cpr`, `height`).
"""

import re
import sys
from pathlib import Path

sys.path.insert(0, "/home/user/ipu-emulator/tools")
from upper_mnemonics import upper_text  # noqa: E402

old, out, crmap_arg, title = sys.argv[1:5]
CRMAP = dict(item.split("=") for item in crmap_arg.split(","))
text = Path(old).read_text()
# 1. the ipu:params header and the "harness assembles ... per run" note after it
text = re.sub(r"\{#- ipu:params.*?-#\}\n", "", text, flags=re.S)
text = re.sub(r"\{#- The harness assembles.*?-#\}\n", "", text, flags=re.S)
text = text.replace("{%- set CPR = cpr -%}", "{%- set CPR = cpr -%}{#- [derived] cpr = width / 128 -#}")
text = text.replace("{%- set ROWS = rows -%}", "{%- set ROWS = height -%}")
lines = text.splitlines()
head = []
while lines and (lines[0].startswith("#") or not lines[0].strip()):
    line = lines.pop(0)
    head.append(line[1:].removeprefix(" ") if line.startswith("#") else "")


def code_part(line):
    """Rename CRs in the code part of a line only (before a '#' comment, outside Jinja)."""
    if line.lstrip().startswith(("{#", "{%")):
        return line
    code, sep, comment = line.partition("#")
    code = re.sub(r"\b[cC][rR](\d+)\b",
                  lambda m: "{{ cr.%s }}" % CRMAP[m.group(1)] if m.group(1) in CRMAP else "CR" + m.group(1),
                  code)
    return code + sep + comment


body = "\n".join(code_part(x) for x in lines)
header = ""
if head:
    header = "{#- " + title + "\n\n" + "\n".join("    " + h if h else "" for h in head).rstrip() + "\n-#}\n"
upper, n = upper_text(header + body + "\n")
Path(out).write_text(upper)
print(f"{out}: {n} tokens upper-cased")
