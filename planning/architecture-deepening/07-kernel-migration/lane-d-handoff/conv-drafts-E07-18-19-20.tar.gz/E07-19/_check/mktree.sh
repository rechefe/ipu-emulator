#!/bin/sh
# Throwaway validation tree (read-only on the repo): the checkout's kernels/convolutions
# as it stands (E07-16 landed, E07-17 in progress), plus the E07-18 and E07-19 drafts.
D=/tmp/claude-0/-home-user-ipu-emulator/54c27a5c-a602-5113-867c-87a759940cf5/scratchpad/conv-drafts
C=$D/E07-19/_check
rm -rf $C/tree $C/pylib $D/E07-18/_check/tree $D/E07-18/_check/pylib
mkdir -p $C/tree
cp -r /home/user/ipu-emulator/kernels/convolutions $C/tree/
F=$C/tree/convolutions
for k in pointwise_conv_tpl depthwise_conv_tpl; do cp -r $D/E07-18/$k $F/; done
for k in conv_universal_wide384 depthwise_conv_stride2_narrow depthwise_conv_stride2_128 depthwise_conv_stride2_16; do cp -r $D/E07-19/$k $F/; done
cat $D/E07-18/convolutions/pack_additions.py $D/E07-19/convolutions/pack_additions.py >> $F/pack.py
cat $D/E07-18/convolutions/masks_additions.py >> $F/masks.py
cat $D/E07-18/convolutions/gen_additions.py >> $F/gen.py
grep -v '^#' $D/E07-18/convolutions/registry_additions.toml >> $F/registry.toml
# no torch in this interpreter: drop every golden reference (compare_* compare with the old harness, not a golden)
for t in $F/*/kernel.toml; do sed -i '/^reference = /d; /^op = "conv2d"  /d; /^op = "conv2d" *#/d' $t; sed -i '/^\[benchmark\]/,$d' $t; done
rm -f $F/*/reference.py
ln -s $C/tree $D/E07-18/_check/tree
