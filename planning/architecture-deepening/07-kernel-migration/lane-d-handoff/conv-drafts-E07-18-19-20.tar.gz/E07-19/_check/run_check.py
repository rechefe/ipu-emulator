"""E07-19 draft check (run from the repo root, read-only on it).

conv_universal_wide384: compare_setup and compare_legacy rows, and every case's
program against the E02 digest of its (cpr, rows).
depthwise_conv_stride2_*: compare_setup/compare_legacy refuse a stages kernel
(runner.stage: "a multi-stage kernel has no one program"), so this does their
work by hand for every legacy case: each stage's program against the program
the old harness loaded (and its E02 digest), the output region's bytes after
run_kernel against the old final XMEM, and the summed cycles.
"""
import hashlib, json

from pathlib import Path
from compare_setup import compare_setup
from compare_legacy import compare_kernel
from migration import legacy_case, legacy_case_ids, legacy_run, new_case
from ipu_harness.assembly import assemble, assemble_program
from ipu_harness.cases import expand
from ipu_harness.manifest import check_abi
from ipu_harness.params import plan_case
from ipu_harness.registry import Registry
from ipu_harness.runner import run_kernel
from ipu_isa.formats import ElementFormat
import tempfile

T = Path(__file__).parent / "tree"
reg = Registry.load(T)
assert not reg.invalid, reg.invalid
DIG = json.load(open("src/tools/ipu-apps/test/baselines/asm_digests.json"))
PFX = "src/tools/ipu-apps/src/ipu_apps/kernels/convolutions/"
by_digest = {v["bin_sha256"]: k.removeprefix(PFX) for k, v in DIG.items() if k.startswith(PFX)}
sha = lambda b: hashlib.sha256(b).hexdigest()  # noqa: E731
F = ElementFormat.FP32
ok = True

# -- wide384 ---------------------------------------------------------------------
m = reg.kernel("conv_universal_wide384")
for case in expand(m):
    plan = plan_case(m, case.values, F, case=case.decl)
    d = sha(assemble(plan).to_bin())
    print(f"wide384 {case.name}: program = E02 {by_digest.get(d, 'NONE ' + d[:12])}")
    ok &= d in by_digest
for cid in legacy_case_ids("conv_universal_wide384"):
    rep = compare_setup("conv_universal_wide384", "conv_universal_wide384", cid, root=T)
    expected = {f"LR{i}: old 42405, new 0" for i in (0, 2, 3, 4, 5)}  # the presets
    same = not rep.xmem_total and set(rep.registers) <= expected
    print(f"  compare_setup {cid}: {'IDENTICAL' if rep.identical else ('IDENTICAL but the expected LR presets' if same else rep.describe())}")
    ok &= same
for r in compare_kernel("conv_universal_wide384", m):
    print(f"  compare_legacy {r.case}: binary {r.binary_ok} output {r.output_ok} cycles {r.cycles_old}/{r.cycles_new} {r.notes}")

# -- stride 2 --------------------------------------------------------------------
STAGE2 = {"depthwise_conv_stride2_narrow": "num_out_groups", "depthwise_conv_stride2_128": "num_row_pairs",
          "depthwise_conv_stride2_16": "num_channel_pairs"}
MAPS = {
    "depthwise_conv_stride2_narrow": {"channels=2,height=8,width=64,seed=3": "rpc2_c2",
                                      "channels=3,height=32,width=16,seed=11": "rpc8_c3"},
    "depthwise_conv_stride2_128": {"channels=4,height=16,seed=7": "c4_h16", "channels=3,height=32,seed=11": "c3_h32",
                                   "channels=32,height=128,seed=13": "c32_h128"},
    "depthwise_conv_stride2_16": {"channels=4,seed=7": "c4", "channels=320,seed=13": "c320"},
}
print("\n| kernel | case | stage programs = old (E02) | output bytes | cycles old/new |\n|---|---|---|---|---|")
for name, count in STAGE2.items():
    m = reg.kernel(name)
    for cid in legacy_case_ids(name):
        case = new_case(m, cid, MAPS[name])
        with tempfile.TemporaryDirectory() as tmp:
            old = legacy_run(name, legacy_case(name, cid), Path(tmp))
        plan = plan_case(m, case.values, F, case=case.decl)
        s1 = assemble_program(plan, m.directory / "../depthwise_conv_tpl/depthwise_conv_tpl.asm", params={},
                              abi=None).to_bin()
        s2abi = check_abi(m, {"y": "CR3", "in_channels": "CR4", "out": "CR5", count: "CR6"}, where="stage 2")
        s2 = assemble_program(plan, m.directory / f"{name}.asm", abi=s2abi).to_bin()
        progs = old.programs == [s1, s2]
        new = run_kernel(m, case, F)
        region = new.placement.region("out")
        start, size = region.base_row * 512, region.rows * 512
        out_ok = old.state.xmem.snapshot_bytes(start, size) == new.raw_outputs["out"]
        e02 = " / ".join(by_digest.get(sha(p), "none") for p in (s1, s2))
        print(f"| {name} | {cid} | {'yes' if progs else 'NO'} ({e02}) | {'yes' if out_ok else 'NO'} | {old.cycles}/{new.cycles} |")
        ok &= progs and out_ok and old.cycles == new.cycles and new.fault is None
print("ALL OK" if ok else "FAILURES")

# compare_legacy's own multi-stage path (30e16beb), from poisoned registers
print("\n| kernel | case | binary | output | cycles old/new | notes |\n|---|---|---|---|---|---|")
for name in ["conv_universal_wide384", *STAGE2]:
    for r in compare_kernel(name, reg.kernel(name), MAPS.get(name, {})):
        print(f"| {r.kernel} | {r.case} | {'yes' if r.binary_ok else 'NO'} | {'yes' if r.output_ok else 'NO'} | {r.cycles_old}/{r.cycles_new} | {'; '.join(r.notes)} |")
