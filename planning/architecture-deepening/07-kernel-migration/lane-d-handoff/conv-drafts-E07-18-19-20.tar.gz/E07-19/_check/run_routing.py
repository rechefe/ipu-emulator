"""Routing of the E07-19 kernels: the family test.py test_resolve rows and the per-kernel refusals."""
from pathlib import Path
from ipu_harness.registry import Registry
reg = Registry.load(Path(__file__).parent / "tree")
def q(**o):
    return dict(in_channels=3, out_channels=4, kernel_size=3, stride=1, padding=1, dilation=1, groups=1,
                has_bias=False, apply_relu=False, height=16, width=16) | o
rows = [
    (dict(in_channels=4, out_channels=4, groups=4, stride=2, height=8, width=128), "depthwise_conv_stride2_128"),
    (dict(in_channels=4, out_channels=4, groups=4, stride=2, height=16, width=32), "depthwise_conv_stride2_narrow"),
    (dict(in_channels=4, out_channels=4, groups=4, stride=2, height=16, width=16), "depthwise_conv_stride2_16"),
    (dict(width=384, out_channels=4), "conv_universal_wide384"),
    (dict(width=512, out_channels=4), "conv_universal_wide384"),
    (dict(width=640, out_channels=4), "conv_universal_wide384"),
    # refusals (stride2 test.py constructors, wide384 test.py)
    (dict(in_channels=1, out_channels=1, groups=1, stride=2, height=5, width=64), None),
    (dict(in_channels=1, out_channels=1, groups=1, stride=2, height=16, width=16), None),  # stride2_narrow test.py (16, 16): rows_per_chunk 8 needs height % 32; _16 needs even channels
    (dict(in_channels=1, out_channels=1, groups=1, stride=2, height=5, width=128), None),
    (dict(in_channels=3, out_channels=3, groups=3, stride=2, height=16, width=16), None),
    (dict(in_channels=1, out_channels=3, height=8, width=384), None),
    (dict(width=200), None), (dict(width=385), None),
]
for o, want in rows:
    v = reg.resolve("conv2d", **q(**o))
    got = v.kernel.name if v else None
    print(f"{'ok ' if (got == want) else '?? '} {o} -> {got}  (want {want})" + ("" if v else f"\n      {v.reason[:260]}"))
