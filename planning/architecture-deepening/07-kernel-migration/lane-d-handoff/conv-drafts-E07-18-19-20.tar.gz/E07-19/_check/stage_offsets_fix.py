"""Monkeypatch for the check only (the repo is not edited): a stage run with
abi=None uses the kernel's [abi], offsets included. At bfc3b65f stages.py passes
manifest.abi explicitly to register_writes(abi=...), which (since 0d575333)
drops the [abi] offsets for any explicit table, so stage 1's CR2 is base(y)
instead of base(y) - 1. The fix is one line in stages.py: register_writes(...,
abi=None if abi is None else bindings)."""
import ipu_harness.stages as stages
from ipu_harness import abi as _abi

_orig = _abi.register_writes


def register_writes(plan, placement, abi=None, dstructure=None):
    if abi is plan.manifest.abi:
        abi = None
    return _orig(plan, placement, abi=abi, dstructure=dstructure)


stages.register_writes = register_writes
