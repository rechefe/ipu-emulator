"""DRAFT (E07-19): depthwise_conv_stride2_narrow's two programs (E06-14).

Stage 1: depthwise_conv_tpl's program, plain variant, at full resolution, with
the kernel's [abi] (depthwise_conv_tpl's table; CR15 its partitioned
dstructure). Stage 2: this folder's program reads stage 1's output (scratch y)
through CR3 (a stage's table binds y at its base, not [abi]'s offset -1) and writes out; CR15 the default dstructure (valid 128, P0), as
today's stage2_setup wrote it. Today's PC reset is load_program's.
"""

STAGE1 = "../depthwise_conv_tpl/depthwise_conv_tpl.asm"


def run(ctx):
    ctx.run_stage(STAGE1)  # has_bias = apply_relu = false: the unseeded program
    ctx.run_stage(
        "depthwise_conv_stride2_narrow.asm",
        abi={"y": "CR3", "in_channels": "CR4", "out": "CR5", "num_out_groups": "CR6"},
    )
