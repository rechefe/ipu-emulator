"""DRAFT (E07-19): addition to kernels/convolutions/pack.py (after E07-18's).

wide384 reuses E07-16's ``row_interleaved`` (x and y: ``(c, h, w)`` stored
``(h, c, w)``, = W app.py:279-285 and 315-326) and ``conv_weight_groups``
(w: 14 input channels a row for 3x3 = W ``_pack_conv_weights_dense_fp32``,
app.py:116-142). The narrow and 128 stride-2 outputs are
``ipu_kernels.pack.chunk_interleaved`` (N app.py:240-253; S128 app.py:224-235).

* ``channel_pairs`` -- depthwise_conv_stride2_16's output (S16 app.py:211-226):
  ``(channels, 8, 8)``, channels even, as ``channels / 2`` rows, channel 2p in
  lanes 0..63 and 2p + 1 in 64..127, each 8x8 row-major: the tensor flattened.
"""


class ChannelPairs:
    """``(channels, h, w)`` with ``2 * h * w == 128``: two channels a row."""

    @staticmethod
    def _check(shape: tuple[int, ...]) -> None:
        if len(shape) != 3 or shape[0] % 2 or 2 * shape[1] * shape[2] != LANES:
            raise ValueError(f"channel_pairs lays out (even channels, h, w), 2*h*w = 128, not {shape}")

    def rows(self, shape: tuple[int, ...], plan: CasePlan) -> int:
        """``channels / 2`` rows."""
        self._check(shape)
        return shape[0] // 2

    def to_rows(self, a: Array, plan: CasePlan) -> Array:
        """``a`` flattened, 128 elements a row."""
        self._check(a.shape)
        return np.asarray(a, dtype=np.float64).reshape(-1, LANES)

    def from_rows(self, r: Array, plan: CasePlan, shape: tuple[int, ...]) -> Array:
        """The ``shape`` tensor ``r`` holds."""
        return r.reshape(shape)


channel_pairs = ChannelPairs()
