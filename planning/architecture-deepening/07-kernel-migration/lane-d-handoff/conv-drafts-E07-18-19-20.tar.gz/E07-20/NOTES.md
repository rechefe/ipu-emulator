# E07-20 prep: conv bias without ReLU (`conv_universal_bias`, `pointwise_conv_unified_bias`, `depthwise_conv_universal_bias`)

Checkout f0fc8e2c. Old paths under `src/tools/ipu-apps/src/ipu_apps/kernels/convolutions/`.
E07-20 adds only `registry.toml` entries (over E07-17/18's templates), their cases, the E02
digest rows and the coverage doc. The templates are the sibling drafts:
`conv-drafts/E07-17/conv_universal_tpl/`, `conv-drafts/E07-18/{pointwise_conv_tpl,depthwise_conv_tpl}/`
(params: program switches `bias` (bool) + `activation` ("identity"|"relu"), depthwise also
`slot` (9|10); query fields `has_bias`, `apply_relu`). E07-18 merged the depthwise twins
(with `slot`), so all three entries apply.

| Draft | Destination |
|---|---|
| `registry.toml` | 3 `[[kernel]]` entries appended to `kernels/convolutions/registry.toml` |
| `_alt_templates/` | my independent derivation of the conv_universal and pointwise templates (CRs and packs machine-checked, see below); superseded by the sibling drafts, kept as a cross-check of their `[derived]`/`[abi]` |

`../tools/check_crs.py` reproduces every CR of all 22 conv_universal-twin and 17 pointwise-twin
baseline records from the `_alt_templates` expressions (0 mismatches); `../tools/check_pack.py`
checks the transforms (in `../E07-16/family/ipu_kernels_convolutions/pack.py`) against the old
loaders (0 failures). The new entries have no baseline: they are new kernels.

## 1. CR map (the templates' registers; the new entries write exactly the bn twins' CRs, since they run the bias layout)

### conv_universal (`conv_universal/app.py:288-325`; bn twin `:270-284` identical) — `_alt_templates` names

| CR | old value (line) | new name | expression |
|---|---|---|---|
| CR2 | `output_base_row` (:290) | `y` | tensor base |
| CR3 | `mask_base_row` (:291) | `mask` | scratch base |
| CR4 | `cols` (:294) | `cols` | `16 + 16*min(1,(width-1)//16) + 32*min(1,(width-1)//32) + 64*min(1,(width-1)//64)` = `next_valid_cols` (`app.py:447-456`) |
| CR5 | `kernel_base_row` (:289) | `filters` | tensor base |
| CR6 | `in_group_stride = in_channels` (:190, :298) | `in_channels` | param |
| CR7 | `FPB = 28` (:81, :299) | `fpb` | `28` |
| CR8 | `total_kernel_rows` (:193, :300) | `kernel_rows` | `out_channels * ceil(in_channels / 28) * 2` |
| CR9 | `3 * 128` (:320) | `ring_adv` | `384` |
| CR10 | `input_base_row` (:288) | `x` | tensor base (headroom included in the pack) |
| CR11 | `(n-1)*c + c` (:305-307) | `chunk_limit` | `num_chunks * in_channels`, `num_chunks = rows * cols // 128` (:187), `rows = max(height, ceil(256 / cols))` |
| CR12 | 128 (:316) | `lanes` | `128` |
| CR13 | `SUPER_BLOCK_ROWS = 2` (:317) | `sb_rows` | `2` |
| CR14 | `(384 - 2*cols - 2) & 0xFFFFFFFF` (:325) | `walk_step` | `384 - 2 * cols - 2` (≥ 126) |
| CR15 | `valid_elements=128, partition=P(cols)` (:269-278) | `dstructure_word` | `dstructure(128, partition)`, `partition = 128//cols - 1 + min(1, 128//cols - 1)` (P0/P2/P4/P8 = 0/2/4/8, `ipu_isa/constants.py:52-58`) |

### pointwise_conv_unified (`pointwise_conv_unified/app.py:224-261`; bn `:265`)

| CR | old (line) | new | expression |
|---|---|---|---|
| CR0 | input base 0 read through CR0 (:218-221) | `x` | `row = 0`, binds `CR0` (nothing written) |
| CR2 | mask (:224) | `mask` | scratch |
| CR3 | output (:225) | `y` | tensor |
| CR4 | `num_passes` (:234) | `num_passes` | `ceil(in_channels / 128)` |
| CR5 | `row_groups` (:235) | `row_groups` | `ceil(height * cols / 128)`; `cols` = next power of two ≥ width (`app.py:466-484`) |
| CR6 | 123 (:236) | `pipe_full` | `123` |
| CR7 | out_channels (:237) | `out_channels` | param |
| CR8 | in_channels (:238) | `in_channels` | param |
| CR9 | `(tail - 5) & 0xFFFFFFFF` (:240) | `pipe_tail` | `tail_size - 5` (negative → two's complement by `register_writes`) |
| CR10 | plain: `tail_size` (:241); bn: `bias_base_row` (bn :265) | `tail_size` `when = "not bias"` / `b` `when = "bias"` | shared register, excluding conditions |
| CR11 | `num_passes - 1` (:242) | `passes_last` | |
| CR12 | 128 (:249) | `lanes` | |
| CR13 | 128 (:250) | `pass_stride` | |
| CR14 | kernel base (:226) | `w` | tensor |
| CR15 | default (:261) | — | default |

## 2. Regions

- conv_universal: `x` @0 (`in_channels` headroom rows + `ceil(rows/(128/cols)) * C` data rows),
  `filters` (`O * ceil(C/28) * 2`), `mask` (1), `y` (`O * chunks`); `y` has `after = "mask"`
  so the order is the old `input, kernel, mask, output` (`conv_universal/app.py:207-214`).
- pointwise: `x` pinned @0, `w` (`O * P`), `mask` (1), `b` (`O * P`, only with `bias`), `y`
  (`row_groups * O`); `b` and `y` both `after = "mask"` (followers in declaration order), giving
  bn's `input, kernel, mask, bias, output` (bn `app.py:165-170`) and plain's
  `input, kernel, mask, output`.

## 3. The new entries

| Entry | Template | Fixed params | Cases | Cost |
|---|---|---|---|---|
| `conv_universal_bias` | conv_universal_tpl | `bias = true, activation = "identity", has_bias = true, apply_relu = false` | default, negative_outputs, negative_bias, the 9 plain-variant sweep points (`conv_universal/test.py:33-43`: sweep_28x4 … sweep_w100) | 0 (= plain) |
| `pointwise_conv_unified_bias` | pointwise_conv_tpl | same | default, negative_bias, the 7 sweep points (`pointwise_conv_unified/test.py:10-18`) | 0 |
| `depthwise_conv_universal_bias` | depthwise_conv_tpl | same + `slot = 10` (the bn layout: bias + 9 taps per channel, FPB 25) | default, negative_outputs, negative_bias, the plain sweep (`depthwise_conv_universal/test.py:10-18`) with c25_16 for c28_16 | 0 |

Programs: the bn programs with `ACTIVATE.QUANTIZE identity` (E07-17 change 3 alone). Routing
after E07-20, per template geometry: (has_bias, apply_relu) = (F,F) → plain; (T,T), (F,T) → bn
(has_bias free, zero bias); (T,F) → `*_bias`. No two entries accept one query: has_bias and
apply_relu split the domain, so no tie (`Registry.resolve` tie error never fires; the
registry load check E06-16).

Cases: the template's cases are shared; an entry picks with `cases = [...]`. Data: the same
legacy generators as the bn twin (E07-17's `legacy_universal` draws a bias when `has_bias`), so
`conv_universal_bias:default`'s positive outputs equal `conv_universal_bn_activation:default`'s
outputs — a cheap cross-check for the PR. `negative_bias` (zero weights, bias `-|b| - 0.1`)
is exact for the new entries: the output is the bias itself, which proves no ReLU.

Reference: `ops.conv2d` with bias and no activation, through each template's `[golden]` (conv_universal_tpl's `reference.py`,
which splits `filters`; the pointwise and depthwise templates likewise).  Draft alternative in
`_alt_templates`: pointwise can use `op = "conv2d"` directly, with `b` a plain `[O]` tensor via `pass0_bias`.

Tolerance: the template's `[golden]` (an entry cannot override it): conv_universal_tpl and
pointwise_conv_tpl `FP32_LONG` (E07-17 measured max |diff| 5.6e-6 at K = 504; FP32_ORDER fails the
in_channels = 56 cases), depthwise_conv_tpl `FP32_ORDER`. Old bounds were max |diff| < 1e-2 (3x3,
`cases.py:82`) and < 1e-3 (1x1, `cases.py:83`). Re-measure on the new entries: identity keeps the
negative outputs ReLU zeroed, so their error is not below bn's.
Checks beyond the golden ("every output == bias" for negative_bias, "every output < 0" for
negative_outputs: old `cases.py:213-216`) go to a family `kernels/convolutions/test_bias_variants.py`:
an entry runs only the generated case tests; a template's `test_*.py` runs under the template only
(IMPLEMENTATION-DECISIONS "Reading registry.toml from Bazel"; sibling E07-17 gap S5).

Digests: the three `:assemble_<entry>` digests are new rows in the E02 record
(`src/tools/ipu-apps/test/baselines/asm_digests.json` successor), reason "E07-20 new variant".
Docs: `docs/content/app-coverage.md` lists the entries.

## 4. Open questions and gaps

- **Q-B1 (resolved by the sibling templates).** E07-17's text maps `has_bias` → `bias` and
  `apply_relu` → `activation`, but no alias exists (a query name must be a declared param,
  `params.py:205-210`). The E07-17/18 drafts declare both sets (query `has_bias`/`apply_relu`,
  program `bias`/`activation`), and every entry fixes them consistently; E07-20's entries do the same.
  Hazard: a template run directly with inconsistent defaults (e.g. conv_universal_tpl's defaults
  are all "on") is not routed, so no query sees it.
- **Q-B2 (resolved).** Template folders are `*_tpl`, so no template shares an entry's name
  (`Registry.kernel(name)` answers templates and entries, `registry.py:346-350`).
- **Q-B3 (cross-parameter constraints, depthwise).** depthwise requires
  `groups == in_channels` and `out_channels == in_channels`
  (`depthwise_conv_universal/app.py:345-351`, bn :299-306). Domains are per parameter; the only
  workaround is a `[derived]` value that is whole only when equal
  (`"1 / (1 + (groups - in_channels) * (groups - in_channels))"`), whose refusal message
  ("must be a whole number") hides the reason. An E06 `requires`/constraint key is the fix.
  Affects E07-18 first; E07-20's depthwise entry inherits it.
- **Q-B4 (the depthwise (F,T) hole).** The depthwise bn twin requires has_bias
  (`depthwise_conv_universal_bn_activation/app.py:310-311`); E07-18's entry keeps
  `has_bias = true` fixed. After E07-20 depthwise (has_bias=False, apply_relu=True) is still
  refused, against E07-20's acceptance "every combination routes". Freeing has_bias on the bn entry
  (zero bias, as the other bn twins) changes an existing entry's routing, which E07-20's third test
  forbids. Decide which wins (a fourth entry `depthwise_conv_universal_relu` = slot 10, bias program,
  has_bias false, would also close it without touching the bn entry).
- **Q-B5 (depthwise slot is a param).** `slot` (9|10) is fixed per entry because a bool cannot
  enter an expression; the bias entry must fix `slot = 10` with `bias = true` (slot 9 has no bias
  element). Nothing enforces the pairing; a family test should (`test_bias_variants.py`).
- **Q-B6 (latent bug: conv input overrun).** `num_chunks = rows * cols // 128` (floor,
  `conv_universal/app.py:187`) while `pack_input_chunked` writes `ceil(rows / (128 // cols))`
  chunks (`app.py:194-196`): e.g. height 17, width 16 writes 3 chunks into a 2-chunk region.
  The drafted packs size regions by what they write (ceil), so placement differs from the old
  layout for such shapes, while CR11 keeps the floor (old loop bound). No case uses such a shape;
  note it, do not fix (behaviour change). Same pattern: depthwise (`depthwise_conv_universal/app.py:180`).
- **Q-B7 (pointwise weights truncation).** The old pointwise harness reads `kernel_path` with
  `np.frombuffer` and slices (`pointwise_conv_unified/app.py:208-209, 189-192`): an oversize file
  is silently truncated. The new `w [O, C, 1, 1]` shape is exact (L15): an oversize input is now an
  error. Not a case today; mention in the E07-18 PR.
- **Q-B8 (depthwise chunk count).** depthwise rounds its chunk count down while the packer
  rounds up (as Q-B6). Inherited by a depthwise bias entry.
- **Q-B9 (old refusals that become accepts).** `convolutions/test.py:221` (`Conv2d(3,4,k=3,
  p=1,bias=True)`, reason "apply_relu") and `:230` (`Conv2d(8,8,k=1,bias=True)`, "apply_relu")
  expect refusals; after E07-20 they route to `conv_universal_bias` / `pointwise_conv_unified_bias`.
  Those rows move to `test_resolve` as accepts, with this issue as the reason.
- **Q-B10 (header drift found while reading).** conv_universal.asm's header says
  "cr13 = 256" (harness: 2, `app.py:317`) and "cols ∈ {16,32,64}; cols=128 lives in a separate
  binary" (cols 128 runs here: baseline sweeps at width 128). Fix in E07-17's header.
- **Q-B11 (issue line refs).** E07-20 cites `conv_universal/app.py:364-367` (actual 355-358),
  `conv_universal_bn_activation/app.py:318-320` (actual 312-317), `pointwise_conv_unified/app.py:300-304`
  (actual 297-302), pointwise bn `:323-325` (actual 320-325).
- Removed by f0fc8e2c: the pointwise bias stride needed `rows(shape, plan)` (`pass0_bias` reads
  `plan.params["in_channels"]`; before, the bias had to be declared `[O, P]`); CR15's partition
  needed `dstructure()`; family transforms may live in `kernels/convolutions/pack.py`.

## 5. Tests (for DELETIONS.md "### Tests from <path>")

E07-20 deletes no test file. It changes the routing tests that E07-16..18 ported:

### Tests from `src/tools/ipu-apps/src/ipu_apps/kernels/convolutions/test.py` (rows E07-20 touches)
| Test | Checks | Now covered by |
|---|---|---|
| `test_refusals[Conv2d(3,4,k3,p1,bias=True)-(3,8,8)-apply_relu]` | bias without ReLU refused | `kernels/convolutions/test_routing.py::test_resolve[bias_no_relu_3x3]` → `conv_universal_bias` (behaviour change, this issue) |
| `test_refusals[Conv2d(8,8,k1,bias=True)-(8,8,8)-apply_relu]` | same, pointwise | `test_routing.py::test_resolve[bias_no_relu_1x1]` → `pointwise_conv_unified_bias` |
| `test_resolve[...]` (12) | unchanged answers | `test_routing.py::test_resolve`, plus new rows for the three entries |
| (new) | every (has_bias, apply_relu) combination per template geometry | `test_routing.py::test_every_bias_relu_combination_routes` (depthwise (F,T) per Q-B4) |
| (new) | negative_bias output equals the bias exactly; negative_outputs all < 0, for the 3 new entries | `kernels/convolutions/test_bias_variants.py` |

### Tests from `.../conv_universal/test.py`, `.../conv_universal_bn_activation/test.py` (E07-17)
| `test_case` (CASES + 9-point sweep each) | template cases `default`, `negative_outputs` / `negative_bias`, `s_*` run by the entries `conv_universal`, `conv_universal_bn_activation` (one-point sweeps keep the E02 record names) |

### Tests from `.../pointwise_conv_unified/test.py`, `.../pointwise_conv_unified_bn_activation/test.py` (E07-18)
| `test_case` (CASES + 7-point sweep each) | template cases `default`, `negative_bias`, `s_*` via the two entries |

### Tests from `.../depthwise_conv_universal/test.py`, `.../depthwise_conv_universal_bn_activation/test.py` (E07-18)
| `test_case` (CASES + 9-point sweep each) | depthwise_conv_tpl cases via the two entries (E07-18); E07-20 adds `depthwise_conv_universal_bias` runs |
