# E07-20 prep: conv bias without ReLU (`conv_universal_bias`, `pointwise_conv_unified_bias`, `depthwise_conv_universal_bias`)

Draft only; nothing in the repo is edited. **Rewritten at HEAD 9df1033f in the
one-parameter-set form**: the templates read `has_bias` and `apply_relu`
themselves. The templates are `kernels/convolutions/conv_universal_tpl`
(landed, E07-17) and the E07-18 drafts `../E07-18/{pointwise_conv_tpl,
depthwise_conv_tpl}`.

The superseded two-set drafts (`bias`/`activation`/`slot` program params) are
kept as `registry.toml.old-two-param-sets`, `NOTES.old-two-param-sets.md` and
`_alt_templates/`. Their CR maps and old-source line refs still hold;
only the parameter names changed.

## The entries (`registry.toml`)

Each entry fixes `has_bias = true` and `apply_relu = false`. Every template
parameter is `query_required` (the templates declare them so, with no
defaults, so an entry's fixed value stands in).

| Entry | Template | Fixed | Cases |
|---|---|---|---|
| `conv_universal_bias` | `conv_universal_tpl` | `has_bias = true, apply_relu = false` | default, negative_outputs, negative_bias, the plain variant's 9 sweep points |
| `pointwise_conv_unified_bias` | `pointwise_conv_tpl` | same | default, negative_bias, the 7 sweep points: **BLOCKED (B1)** |
| `depthwise_conv_universal_bias` | `depthwise_conv_tpl` | same, plus `fpb = 25` (the seeded layout: bias + 9 taps, 25 channels a block) | default, negative_outputs, negative_bias, the plain sweep with c25_16 for c28_16 |

How each program behaves at (T, F): seeded (`has_bias or apply_relu`), ACTIVATE
`identity`. The packs (`fpb28_filters` / `depthwise_filters` /
`pass0_bias`) store the bias because `has_bias`, and the references add it
because `has_bias`.

Cost is the template's: 0 for conv_universal_tpl and pointwise_conv_tpl, 1 for
depthwise_conv_tpl (it yields to conv_universal at C = 1, as its twins do).

## Result (`_check/run_check.py`, `_check/run_check.out`, 20:42 UTC; the E07-19 tree plus these entries)

| Entry | Routes (T, F) | Every case runs to HALT | Program |
|---|---|---|---|
| `conv_universal_bias` | yes | 12/12 | one new binary `232b76890be6...` (not an E02 digest: the bn program with ACTIVATE identity) |
| `depthwise_conv_universal_bias` | yes | 12/12 | one new binary `a30a9dcc0c25...` (new) |
| `pointwise_conv_unified_bias` | yes | 9/9 | **`7854737d5b52...` = `pointwise_conv_unified`'s E02 program: the bias is not read (B1)** |

**Not checked** (no torch in the checking interpreter, and no bazel):
- the goldens and the tolerance tier of the new entries;
- `negative_bias` giving exactly the bias without a clamp, and
  `negative_outputs` staying negative;
- the `:assemble_<entry>` targets and the E02 digest rows the issue adds;
- `registry.bzl` regeneration;
- `docs/content/app-coverage.md`;
- the `test_routing.py` edits.

Routing for the other combinations is unchanged; it is checked under E07-18/19.

## B1: `pointwise_conv_unified_bias` is blocked by CR10's shared binding

For the (T, F) entry, the pointwise bias region must exist, and the program
must be seeded, when `has_bias or apply_relu`. HEAD's conditions take `or`,
so `b`'s `when` and the program's test could both say so. But in the plain
case CR10 holds `tail_size` (written, never read, PW app.py:241), and that
binding needs the complement: `not has_bias and not apply_relu`. There is no
`and`, and `not has_bias` does not exclude `has_bias or apply_relu` (both hold
at (F, T)), so the loader rejects the pair.

The E07-18 draft therefore seeds on `apply_relu` alone (`b`: `when =
"apply_relu"`, `tail_size`: `when = "not apply_relu"`). That is exact for
today's two entries; at (T, F) it renders the plain program and ignores the
bias, as measured above. Decision needed, then a 3-line change to
`pointwise_conv_tpl` (`when`, the `seeded` test, `tail_size`'s binding):

- (a) add `and` (or a "neither" form) to `ipu_harness.conditions`; or
- (b) drop the `tail_size` binding. The plain program never reads CR10, so
  outputs are unchanged, but E07-18's `compare_setup` for
  `pointwise_conv_unified` then reports `CR10: old <tail_size>, new 0xA5A5`
  (the old harness wrote it): an expected difference to log.

## Routing tests that change (behaviour change, this issue)

| Test at HEAD (`kernels/convolutions/test_routing.py`) | After E07-20 |
|---|---|
| `test_bias_and_relu_choose_the_universal_kernel[True-False-None]` | `[True-False-conv_universal_bias]` |
| `test_universal_refusals[params5-apply_relu]` (`universal(has_bias=True)` refused) | moves to the accepts (-> `conv_universal_bias`) |
| E07-18's `test_bias_and_relu_choose_the_pointwise_kernel` (T, F) refused row | -> `pointwise_conv_unified_bias` (after B1) |
| E07-18's `test_bias_and_relu_choose_the_depthwise_kernel` (T, F) refused row | -> `depthwise_conv_universal_bias`; (F, T) stays refused |
| `test_layers.py::test_a_biased_layer_needs_an_explicit_relu` (E07-17) | a biased layer with `apply_relu = False` now routes: the test's premise changes |
| (new) `kernels/convolutions/test_bias_variants.py` | `negative_bias` == the bias exactly, `negative_outputs` all < 0, for the 3 entries |

E07-20 deletes no file, so no DELETIONS.md rows. It adds the entries, their
E02 digest rows (reason "E07-20 new variant") and the coverage-doc lines.

## Inherited latent bugs

The depthwise entry inherits **#258** (the chunk count rounds down while
`chunked_guard` rounds up). The pointwise entry inherits **#259**'s context,
but the new kernel's `pack` already refuses an oversize weight tensor (L15).
Neither is fixed here.
