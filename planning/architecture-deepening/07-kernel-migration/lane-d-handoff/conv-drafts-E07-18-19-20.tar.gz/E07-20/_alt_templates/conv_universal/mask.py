"""DRAFT kernels/convolutions/conv_universal/mask.py: `bytes` must name a file in the kernel folder."""

from ipu_kernels.convolutions.pack import border_mask_bytes


def border_mask(plan) -> bytes:
    return border_mask_bytes(int(plan.derived["cols"]))
