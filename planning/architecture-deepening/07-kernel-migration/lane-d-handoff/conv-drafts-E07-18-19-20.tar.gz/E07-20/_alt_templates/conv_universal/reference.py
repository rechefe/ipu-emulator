"""DRAFT kernels/convolutions/conv_universal/reference.py: split `filters` (G3 option a)."""

from ipu_kernels.reference.ops import conv2d


def reference(x, filters, *, bias, **params):
    c = x.shape[0]
    w = filters[:, :-1].reshape(filters.shape[0], c, 3, 3)
    b = filters[:, -1] if bias else None     # bias = false: the column is not stored, so ignore it
    return conv2d(x, w, b, **params)          # apply_relu from params
