"""DRAFT additions to kernels/convolutions/gen.py for the universal templates (E07-17/18; used
unchanged by the E07-20 entries). Ports convolutions/cases.py:125-176 (_data + data=...).
`bias` here is the template's program switch: the old _data drew a bias iff the case was a
bn-twin case (bias=True), so the draws stay identical per entry."""

import numpy as np

from gen import _universal  # same file in reality


def _as_inputs(plan, x, w, b):
    p = plan.params
    if p["kernel_size"] == 3:   # conv_universal: filters = [taps | bias]
        filters = np.concatenate([w.reshape(w.shape[0], -1), b[:, None]], axis=1)
        return {"x": x, "filters": filters}
    out = {"x": x, "w": w}       # pointwise
    if p["bias"]:
        out["b"] = b
    return out


def legacy_universal_seed0(plan, rng):
    x, w, b = _universal(0, plan, bias=plan.params["bias"])
    return _as_inputs(plan, x, w, b)


def legacy_universal_negative(plan, rng):        # cases.py:170-172
    x, w, b = _universal(0, plan, bias=plan.params["bias"])
    return _as_inputs(plan, np.full_like(x, 5.0), -np.ones_like(w), b)


def legacy_universal_negative_bias(plan, rng):   # cases.py:173-176 (always drawn with a bias)
    x, w, b = _universal(0, plan, bias=True)
    # float32 arithmetic, as the old float32 arrays did (NEP 50: 0.1 becomes float32 0.1)
    neg = (-np.abs(b.astype(np.float32)) - np.float32(0.1)).astype(np.float64)
    return _as_inputs(plan, np.ones_like(x), np.zeros_like(w), neg)
