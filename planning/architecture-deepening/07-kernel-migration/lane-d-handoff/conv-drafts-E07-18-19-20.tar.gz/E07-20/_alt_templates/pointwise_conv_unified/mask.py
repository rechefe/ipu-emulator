"""DRAFT kernels/convolutions/pointwise_conv_unified/mask.py."""

from ipu_kernels.convolutions.pack import keep_all_mask_bytes


def keep_all(plan) -> bytes:
    return keep_all_mask_bytes()
