"""E07-20 draft check (no torch: no golden): the three entries load, (has_bias, apply_relu)
routes to them, every case plans, renders, runs to HALT, and the program is new
(not an E02 digest: the bn programs with ACTIVATE identity)."""
import hashlib, json
from pathlib import Path
import numpy as np
from ipu_harness.assembly import assemble
from ipu_harness.cases import expand
from ipu_harness.params import plan_case
from ipu_harness.registry import Registry
from ipu_harness.runner import run_kernel, stage
from ipu_isa.formats import ElementFormat
F = ElementFormat.FP32
reg = Registry.load(Path(__file__).parent / "tree")
assert not reg.invalid, reg.invalid
DIG = {v["bin_sha256"] for v in json.load(open("src/tools/ipu-apps/test/baselines/asm_digests.json")).values()}
geo = {"conv_universal_bias": dict(kernel_size=3, padding=1, groups=1, in_channels=4, out_channels=4),
       "pointwise_conv_unified_bias": dict(kernel_size=1, padding=0, groups=1, in_channels=8, out_channels=8),
       "depthwise_conv_universal_bias": dict(kernel_size=3, padding=1, groups=4, in_channels=4, out_channels=4)}
for name, g in geo.items():
    q = dict(g, stride=1, dilation=1, height=16, width=16, has_bias=True, apply_relu=False)
    v = reg.resolve("conv2d", **q)
    print(f"route (T, F) {name}: -> {v.kernel_name if v else 'refused: ' + v.reason[:120]}")
    m = reg.kernel(name)
    digests, halted = set(), True
    for case in expand(m):
        plan = plan_case(m, case.values, F, case=case.decl)
        digests.add(hashlib.sha256(assemble(plan).to_bin()).hexdigest())
        r = run_kernel(m, case, F)
        halted &= r.halted and r.fault is None
    print(f"  {len(list(expand(m)))} cases run to HALT: {halted}; programs {len(digests)}, new (not E02): {not (digests & DIG)}, digest {sorted(digests)[0][:12]}")
