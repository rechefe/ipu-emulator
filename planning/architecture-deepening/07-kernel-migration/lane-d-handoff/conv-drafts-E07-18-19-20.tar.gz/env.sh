# The checking interpreter and path (E07-17's env.sh without its stale pylib), for the conv drafts.
. /tmp/claude-0/-home-user-ipu-emulator/54c27a5c-a602-5113-867c-87a759940cf5/scratchpad/conv-drafts/E07-17/_check/env.sh
export PYTHONPATH=$(echo "$PYTHONPATH" | tr ':' '\n' | grep -v 'E07-17/_check/pylib' | paste -sd:)
