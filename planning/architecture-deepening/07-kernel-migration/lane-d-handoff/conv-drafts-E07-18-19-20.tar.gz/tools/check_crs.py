"""Recompute every CR of the drafted [derived]/[abi] tables from case params and
the drafted pack row counts (sequential placement), and compare with the E02
baseline.json CR arrays. Read-only: reads the repo's baseline.json files."""
import json, math, sys
ROOT = "/home/user/ipu-emulator/src/tools/ipu-apps/src/ipu_apps/kernels/convolutions"
ceil = lambda a, b: -(-a // b)

def place(regions):  # [(name, rows)] sequential from row 0
    out, cur = {}, 0
    for n, r in regions:
        out[n] = cur; cur += r
    return out

def convapp(k, single, c, h, w, o):
    halo = k // 2; cols = 128 if k == 1 else 126
    tiles = ceil(w, cols); gs = 128 // (k * k); groups = ceil(c, gs)
    regs = [("x", c * (h + 2 * halo) * tiles)]
    if not single: regs.append(("guard", (h + 2 * halo) * tiles))
    regs += [("w", o * groups), ("b", o), ("y", o * h * tiles)]
    b = place(regs)
    cr = [0] * 16; cr[1] = 1; cr[15] = 128
    cr[2], cr[3], cr[4], cr[5] = b["x"], b["y"], b["w"], b["b"]
    if single:
        cr[6], cr[7], cr[8], cr[9], cr[10], cr[11] = tiles, h, o, 126, 128, tiles - 1
    else:
        cr[6], cr[7], cr[8], cr[9], cr[10], cr[11], cr[12] = h * tiles, tiles, h, c, o, groups, 128
        if k == 3: cr[13], cr[14] = 13, 126
    return cr

def cols3(w): return 16 + 16*min(1,(w-1)//16) + 32*min(1,(w-1)//32) + 64*min(1,(w-1)//64)
def part(cols):
    g = 128 // cols; return g - 1 + min(1, g - 1)

def conv_universal(c, o, h, w, bias):
    cols = cols3(w); rows = max(h, ceil(256, cols)); n = rows * cols // 128
    regs = [("x", c + c * ceil(rows, 128 // cols)), ("filters", o * ceil(c, 28) * 2), ("mask", 1), ("y", o * ceil(rows, 128 // cols))]
    b = place(regs)
    cr = [0] * 16; cr[1] = 1
    cr[10], cr[5], cr[2], cr[3] = b["x"], b["filters"], b["y"], b["mask"]
    cr[4], cr[6], cr[7], cr[8] = cols, c, 28, o * ceil(c, 28) * 2
    cr[11], cr[12], cr[13], cr[9], cr[14] = n * c, 128, 2, 384, 384 - 2 * cols - 2
    cr[15] = 128 + 256 * part(cols)
    return cr

def pcols(w): return 1 + sum(p*min(1,(w-1)//p) for p in (1,2,4,8,16,32,64))
def pointwise(c, o, h, w, bias):
    cols = pcols(w); rg = ceil(h * cols, 128); P = ceil(c, 128); tail = c - (P - 1) * 128
    regs = [("x", rg * c), ("w", o * P), ("mask", 1)] + ([("b", o * P)] if bias else []) + [("y", rg * o)]
    b = place(regs)
    cr = [0] * 16; cr[1] = 1; cr[15] = 128
    cr[2], cr[3], cr[14] = b["mask"], b["y"], b["w"]
    cr[4], cr[5], cr[6], cr[7], cr[8] = P, rg, 123, o, c
    cr[9] = (tail - 5) & 0xFFFFFFFF
    cr[10] = b["b"] if bias else tail
    cr[11], cr[12], cr[13] = P - 1, 128, 128
    return cr

def first_layer():
    cr = [0,1,0,2048,2080,2560, 256//128, 3*256//128, 1, 2*3*256//128, 0, 256//2, 16, 2082, 128, 128]
    return cr

def opts(name, kernel):
    """case name -> option dict, from the old cases.py defaults + sweep names."""
    import re
    if "=" in name:
        return {k: int(v) for k, v in (p.split("=") for p in name.split(","))}
    return None

bad = 0
def check(kernel, case, got):
    global bad
    want = json.load(open(f"{ROOT}/{kernel}/baseline.json"))[case]["programs"][0]["cr"]
    if got != want:
        bad += 1; print("MISMATCH", kernel, case, "\n  got ", got, "\n  want", want)
    else:
        print("ok", kernel, case)

CA = {"default": (3,3,8,2), "tile_boundary": (2,2,133,2), "single_pixel": (1,1,1,1)}
for k, single, name in ((1, False, "conv1x1"), (3, False, "conv3x3_relu"), (3, True, "conv3x3_relu_cin1")):
    cases = dict(CA)
    if single:
        cases = {"default": (1,3,8,2), "tile_boundary": (1,2,133,2), "single_pixel": (1,1,1,1)}
    else:
        cap = 128 if k == 1 else 14
        cases["full_group"] = (cap,1,2,1); cases["partial_group"] = (cap+1,1,2,2)
    for cname, (c,h,w,o) in cases.items():
        check(name, cname, convapp(k, single, c, h, w, o))
check("conv_first_layer", "default", first_layer())

for name, bias, named in (("conv_universal", False, {"default": (16,4,16,16), "negative_outputs": (4,4,16,16)}),
                          ("conv_universal_bn_activation", True, {"default": (16,4,16,16), "negative_bias": (8,2,16,16)})):
    recs = json.load(open(f"{ROOT}/{name}/baseline.json"))
    for cname in recs:
        if cname in named: c,o,h,w = named[cname]
        else:
            d = opts(cname, name); c,o,h,w = d["in_channels"], d["out_channels"], d["height"], d["width"]
        check(name, cname, conv_universal(c,o,h,w,bias))
for name, bias, named in (("pointwise_conv_unified", False, {"default": (16,8,16,16)}),
                          ("pointwise_conv_unified_bn_activation", True, {"default": (16,8,16,16), "negative_bias": (8,8,16,16)})):
    recs = json.load(open(f"{ROOT}/{name}/baseline.json"))
    for cname in recs:
        if cname in named: c,o,h,w = named[cname]
        else:
            d = opts(cname, name); c,o,h,w = d["in_channels"], d["out_channels"], d["height"], d["width"]
        check(name, cname, pointwise(c,o,h,w,bias))
print("mismatches:", bad)
