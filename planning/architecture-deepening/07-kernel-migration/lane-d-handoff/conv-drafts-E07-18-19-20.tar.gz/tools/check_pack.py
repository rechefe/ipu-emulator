"""Compare the drafted pack transforms with the old loaders' bytes (functions
extracted from the repo sources with ast, run on numpy only)."""
import ast, importlib.util, sys, types
import numpy as np
APPS = "/home/user/ipu-emulator/src/tools/ipu-apps/src/ipu_apps"
DRAFT = sys.argv[1]

def grab(path, names, ns):
    tree = ast.parse(open(path).read())
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.Assign)) and (
            getattr(node, "name", None) in names
            or (isinstance(node, ast.Assign) and any(getattr(t, "id", None) in names for t in node.targets))):
            exec(compile(ast.Module([node], []), path, "exec"), ns)
    return ns

ns = {"np": np, "math": __import__("math"), "CHUNK_ELEMENTS": 128, "CHUNK_BYTES": 128}
grab(f"{APPS}/kernel_registry/case_support.py", {"tile_input", "untile_output"}, ns)
grab(f"{APPS}/kernels/convolutions/app.py", {"pack_input_chunked", "unpack_output_chunked", "next_valid_cols",
     "min_rows_for_chunk_floor", "pointwise_pad_shape", "build_border_mask_blob", "_VALID_COLS",
     "MASK_SLOT_NONE", "MASK_SLOT_TOP", "MASK_SLOT_BOTTOM"}, ns)
plain = dict(ns, SUPER_BLOCK_ELEMENTS=256, FPB=28)
grab(f"{APPS}/kernels/convolutions/conv_universal/app.py", {"_pack_conv_weights_fpb28"}, plain)
bn = dict(ns, SUPER_BLOCK_ELEMENTS=256, FPB=28, BIAS_ELEMENT_OFFSET=1)
grab(f"{APPS}/kernels/convolutions/conv_universal_bn_activation/app.py", {"_pack_conv_weights_fpb28"}, bn)

spec = importlib.util.spec_from_file_location("draftpack", DRAFT)
P = importlib.util.module_from_spec(spec); spec.loader.exec_module(P)
rng = np.random.default_rng(1)
fails = 0
def same(label, a, b):
    global fails
    a = np.asarray(a, dtype=np.float32).reshape(-1); b = np.asarray(b, dtype=np.float32).reshape(-1)
    ok = a.shape == b.shape and np.array_equal(a, b)
    fails += not ok
    print("ok  " if ok else "FAIL", label, a.shape, b.shape)

class Plan:  # stand-in for CasePlan
    def __init__(self, **p): self.params = p

# ConvApp input/outputs/weights/bias
for (c, h, w, o, k, guard) in [(3,3,8,2,1,True),(2,2,133,2,1,True),(1,1,1,1,1,True),(128,1,2,1,1,True),(129,1,2,2,1,True),
                               (3,3,8,2,3,True),(2,2,133,2,3,True),(14,1,2,1,3,True),(15,1,2,2,3,True),(1,3,8,2,3,False),(1,2,133,2,3,False)]:
    x = rng.standard_normal((c, h, w)); wt = rng.standard_normal((o, c, k, k)); b = rng.standard_normal(o)
    old = ns["tile_input"](x.astype("<f4"), halo=k // 2, guard=guard)
    tr = P.tiled_guard if k == 1 else (P.halo_tiled_guard if guard else P.halo_tiled)
    new = tr.to_rows(x, None); assert tr.rows(x.shape) == new.shape[0]
    same(f"input k={k} c={c} h={h} w={w} guard={guard}", old, new)
    same("input inverse", tr.from_rows(new, None, x.shape), x)
    # weights (cases.py:44-49)
    gs = 128 if k == 1 else 14; groups = -(-c // gs)
    img = np.zeros((o * groups + o, 128), dtype="<f4")
    for oo in range(o):
        for g in range(groups):
            ch = wt.astype("<f4")[oo, g * gs:(g + 1) * gs].ravel(); img[oo * groups + g, :len(ch)] = ch
        img[o * groups + oo, 0] = b.astype("<f4")[oo]
    neww = P.conv_weight_groups.to_rows(wt, None); assert P.conv_weight_groups.rows(wt.shape) == neww.shape[0]
    same(f"weights+bias k={k} c={c} o={o}", img, np.concatenate([neww, P.lane0_rows.to_rows(b, None)]))
    if k == 3:  # output round trip vs untile_output
        y = rng.standard_normal((o, h, w)); rows = P.tiles126.to_rows(y, None)
        same(f"tiles126 o={o} h={h} w={w}", ns["untile_output"](rows.reshape(-1).astype("<f4"), (o, h, w), columns=126), y)
        same("tiles126 inverse", P.tiles126.from_rows(rows, None, (o, h, w)), y)

# conv_first_layer
x = rng.standard_normal((3, 256, 256)); old = np.ascontiguousarray(x.astype(np.float32).transpose(1, 0, 2))
new = P.row_interleaved.to_rows(x, None); assert new.shape[0] == 1536 == P.row_interleaved.rows(x.shape)
same("row_interleaved input", old, new)
y = rng.standard_normal((16, 128, 128)); assert P.row_interleaved.rows(y.shape) == 2048
same("row_interleaved output inverse", P.row_interleaved.from_rows(P.row_interleaved.to_rows(y, None), None, y.shape), y)

# conv_universal input (with headroom), output, filters, mask
for (c, o, h, w) in [(16,4,16,16),(10,4,16,16),(16,4,8,128),(16,8,32,32),(28,4,16,16),(3,4,8,100),(4,2,5,5),(4,2,8,128),(4,2,8,8),(56,4,16,16),(3,5,4,127)]:
    cols = ns["next_valid_cols"](w); rows = ns["min_rows_for_chunk_floor"](h, cols)
    x = rng.standard_normal((c, h, w)); pad = np.zeros((c, rows, cols), np.float32); pad[:, :h, :w] = x
    old = np.concatenate([np.zeros(c * 128, np.float32), np.frombuffer(ns["pack_input_chunked"](pad, cols), np.float32)])
    new = P.conv3x3_chunked.to_rows(x, None); assert P.conv3x3_chunked.rows(x.shape) == new.shape[0]
    same(f"conv3x3_chunked c={c} h={h} w={w}", old, new)
    yy = rng.standard_normal((o, h, w)); r = P.conv3x3_chunked_out.to_rows(yy, None)
    oldout = ns["unpack_output_chunked"](r.astype(np.float32).tobytes(), o, rows, cols)[:, :h, :w]
    same(f"conv3x3_chunked_out o={o}", oldout, yy)
    wt = rng.standard_normal((o, c, 3, 3)).astype(np.float32); bb = rng.standard_normal(o).astype(np.float32)
    filt = np.concatenate([wt.reshape(o, c * 9), np.zeros((o, 1))], axis=1)
    same(f"fpb28 plain c={c}", np.frombuffer(plain["_pack_conv_weights_fpb28"](wt.reshape(o, c, 9)), np.float32),
         P.fpb28_filters.to_rows(filt, Plan(bias=False)))
    filt[:, -1] = bb
    same(f"fpb28 bias c={c}", np.frombuffer(bn["_pack_conv_weights_fpb28"](wt.reshape(o, c, 9), bb), np.float32),
         P.fpb28_filters.to_rows(filt, Plan(bias=True)))
    same("fpb28 inverse", P.fpb28_filters.from_rows(P.fpb28_filters.to_rows(filt, Plan(bias=True)), Plan(bias=True), filt.shape), filt)
    m = ns["build_border_mask_blob"](cols); same(f"mask cols={cols}", np.frombuffer(m + bytes(384), np.uint8), np.frombuffer(P.border_mask_bytes(cols), np.uint8))

# pointwise
for (c, o, h, w) in [(16,8,16,16),(128,8,16,16),(144,8,16,16),(256,8,16,16),(96,32,32,32),(144,8,3,5),(8,4,1,1),(160,160,8,8)]:
    rows, cols = ns["pointwise_pad_shape"](h, w)
    x = rng.standard_normal((c, h, w)); pad = np.zeros((c, rows, cols), np.float32); pad[:, :h, :w] = x
    same(f"pointwise_chunked c={c} h={h} w={w}", np.frombuffer(ns["pack_input_chunked"](pad, cols), np.float32), P.pointwise_chunked.to_rows(x, None))
    assert P.pointwise_chunked.rows(x.shape) == (rows * cols // 128) * c
    Pn = -(-c // 128); wt = rng.standard_normal((o, c, 1, 1)).astype(np.float32)
    packed = np.zeros(o * Pn * 128, np.float32)
    for oc in range(o):
        for p in range(Pn):
            n = 128 if p < Pn - 1 else c - (Pn - 1) * 128
            packed[(oc * Pn + p) * 128:(oc * Pn + p) * 128 + n] = wt.reshape(-1)[oc * c + p * 128: oc * c + p * 128 + n]
    same(f"pointwise_weights c={c}", packed, P.pointwise_weights.to_rows(wt, None))
    bb = rng.standard_normal(o); bpk = np.zeros(o * Pn * 128); bpk[np.arange(o) * Pn * 128] = bb
    pl = Plan(in_channels=c); assert P.pass0_bias.rows(bb.shape, pl) == o * Pn
    same(f"pass0_bias c={c}", bpk, P.pass0_bias.to_rows(bb, pl))
    same("pass0_bias inverse", P.pass0_bias.from_rows(P.pass0_bias.to_rows(bb, pl), pl, bb.shape), bb)
print("failures:", fails)
